# Ofir Kadosh Bitcoin AI Dashboard — Full Project Export

Generated: 2026-07-04 19:21:23 UTC
Location: `C:\Users\NORIS\btc-market-analyzer`

## Table of Contents

- [requirements.txt](#file-requirements-txt)
- [.env.example](#file--env-example)
- [.gitignore](#file--gitignore)
- [README.md](#file-README-md)
- [app.py](#file-app-py)
- [generate_export.py](#file-generate_export-py)
- [assets/README.txt](#file-assets-README-txt)
- [src/data/__init__.py](#file-src-data-__init__-py)
- [src/data/binance_client.py](#file-src-data-binance_client-py)
- [src/data/cache.py](#file-src-data-cache-py)
- [src/data/coinglass_client.py](#file-src-data-coinglass_client-py)
- [src/data/data_hub.py](#file-src-data-data_hub-py)
- [src/data/fear_greed.py](#file-src-data-fear_greed-py)
- [src/data/hub_models.py](#file-src-data-hub_models-py)
- [src/data/news_client.py](#file-src-data-news_client-py)
- [src/data/news_sentiment.py](#file-src-data-news_sentiment-py)
- [src/data/onchain.py](#file-src-data-onchain-py)
- [src/data/onchain_client.py](#file-src-data-onchain_client-py)
- [src/data/whale_client.py](#file-src-data-whale_client-py)
- [src/data/connectors/__init__.py](#file-src-data-connectors-__init__-py)
- [src/data/connectors/base.py](#file-src-data-connectors-base-py)
- [src/data/connectors/binance_connector.py](#file-src-data-connectors-binance_connector-py)
- [src/data/connectors/bybit.py](#file-src-data-connectors-bybit-py)
- [src/data/connectors/coinbase.py](#file-src-data-connectors-coinbase-py)
- [src/data/connectors/kraken.py](#file-src-data-connectors-kraken-py)
- [src/data/connectors/okx.py](#file-src-data-connectors-okx-py)
- [src/indicators/technical.py](#file-src-indicators-technical-py)
- [src/analysis/models.py](#file-src-analysis-models-py)
- [src/analysis/scorer.py](#file-src-analysis-scorer-py)
- [src/analysis/sentiment.py](#file-src-analysis-sentiment-py)
- [src/analysis/risk_manager.py](#file-src-analysis-risk_manager-py)
- [src/analysis/ai_decision_engine.py](#file-src-analysis-ai_decision_engine-py)
- [src/ui/__init__.py](#file-src-ui-__init__-py)
- [src/ui/theme.py](#file-src-ui-theme-py)
- [src/ui/time_utils.py](#file-src-ui-time_utils-py)
- [src/ui/helpers.py](#file-src-ui-helpers-py)
- [src/ui/primitives.py](#file-src-ui-primitives-py)
- [src/ui/styles.py](#file-src-ui-styles-py)
- [src/ui/background.py](#file-src-ui-background-py)
- [src/ui/charts.py](#file-src-ui-charts-py)
- [src/ui/sidebar.py](#file-src-ui-sidebar-py)
- [src/ui/dashboard.py](#file-src-ui-dashboard-py)
- [src/ui/components.py](#file-src-ui-components-py)
- [src/ui/tradingview.py](#file-src-ui-tradingview-py)

---

<a id="file-requirements-txt"></a>
## File: `requirements.txt`

```text
streamlit
plotly
pandas
numpy
requests
python-dotenv
feedparser
ta
streamlit-autorefresh
```

---

<a id="file--env-example"></a>
## File: `.env.example`

```text
# Optional: Coinglass API key for liquidation heatmap and enriched derivatives data
COINGLASS_API_KEY=

# Optional on-chain / whale providers (placeholders until live endpoints are wired)
GLASSNODE_API_KEY=
CRYPTOQUANT_API_KEY=
ARKHAM_API_KEY=
WHALE_ALERT_API_KEY=
```

---

<a id="file--gitignore"></a>
## File: `.gitignore`

```text
.venv/
__pycache__/
*.pyc
.env
.streamlit/
```

---

<a id="file-README-md"></a>
## File: `README.md`

```markdown
# Bitcoin Market Analyzer

Python app that analyzes the Bitcoin market using Binance spot/futures data and optional Coinglass derivatives data. Computes EMA, MACD, RSI, volume, and a price heatmap, then outputs a 0–100 score with a **long**, **short**, or **wait** recommendation.

## Features

- Live OHLCV from Binance
- Technical indicators: EMA (9/21/50/200), MACD, RSI, volume analysis
- Heatmap: Coinglass liquidation heatmap (with API key) or Binance volume profile fallback
- Derivatives context: funding rate, long/short ratio, open interest change
- Composite score (0–100), confidence, stop loss, take profit, and written explanation
- Simple Streamlit UI with an **Analyze** button

## Quick start

```bash
cd btc-market-analyzer
python -m venv .venv
.venv\Scripts\activate        # Windows
pip install -r requirements.txt
copy .env.example .env          # optional: add COINGLASS_API_KEY
streamlit run app.py
```

Open the URL shown in the terminal (usually http://localhost:8501).

## Coinglass API (optional)

Coinglass requires a paid API key for programmatic access. Without it, the app still works using Binance data and a volume-profile heatmap.

1. Get an API key from [Coinglass](https://www.coinglass.com/pricing)
2. Add it to `.env`:

```
COINGLASS_API_KEY=your_key_here
```

Or paste it in the sidebar when running the app.

## Scoring logic

| Component | Weight | Bullish when… |
|-----------|--------|---------------|
| EMA Trend | 25% | Price above EMAs, golden cross structure |
| MACD | 20% | MACD above signal, rising histogram |
| RSI | 15% | Oversold bounce or bullish zone (not overbought) |
| Volume | 15% | Above-average volume with taker buy dominance |
| Heatmap | 10% | More liquidation/support intensity below price |
| Derivatives | 15% | Neutral/negative funding, balanced positioning |

- **Score ≥ 62** → Long  
- **Score ≤ 38** → Short  
- **Otherwise** → Wait  

Stop loss and take profit use ATR-based levels adjusted by heatmap support/resistance zones.

## Disclaimer

This tool is for educational and research purposes only. It is not financial advice. Cryptocurrency trading involves substantial risk.
```

---

<a id="file-app-py"></a>
## File: `app.py`

```python
"""Streamlit UI for Bitcoin market analysis."""

from __future__ import annotations

import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.analysis.scorer import MarketAnalyzer
from src.ui.components import (
    render_dashboard,
    render_empty_state,
    render_error_state,
    render_header_bar,
)
from src.ui.sidebar import AUTO_REFRESH_SECONDS, render_sidebar
from src.ui.styles import inject_global_styles
from src.ui.time_utils import normalize_last_updated

load_dotenv(ROOT / ".env")

st.set_page_config(
    page_title="Ofir Kadosh Bitcoin AI Dashboard",
    page_icon="₿",
    layout="wide",
    initial_sidebar_state="expanded",
)


def _get_last_updated() -> datetime | None:
    return normalize_last_updated(st.session_state.get("last_updated"))


def _run_analysis(symbol: str, interval: str, api_key: str) -> None:
    analyzer = MarketAnalyzer(
        symbol=symbol,
        interval=interval,
        coinglass_api_key=api_key or None,
    )
    st.session_state["last_result"] = analyzer.analyze()
    st.session_state["last_updated"] = datetime.now(timezone.utc)


def _auto_refresh(symbol: str, interval: str, api_key: str) -> None:
    seconds = AUTO_REFRESH_SECONDS

    try:
        from streamlit_autorefresh import st_autorefresh

        tick = st_autorefresh(interval=seconds * 1000, key="btc_dashboard_autorefresh")
        if tick > 0 and "last_result" in st.session_state:
            try:
                _run_analysis(symbol, interval, api_key)
            except Exception:
                pass
        return
    except ImportError:
        pass

    try:
        @st.fragment(run_every=timedelta(seconds=seconds))
        def _refresh_worker() -> None:
            try:
                _run_analysis(symbol, interval, api_key)
            except Exception:
                return

        _refresh_worker()
    except TypeError:
        last = normalize_last_updated(st.session_state.get("last_updated"))
        if last is not None:
            elapsed = (datetime.now(timezone.utc) - last).total_seconds()
            if elapsed >= seconds:
                try:
                    _run_analysis(symbol, interval, api_key)
                except Exception:
                    pass
                st.rerun()
            remaining = max(5, int(seconds - elapsed))
            st.markdown(
                f'<meta http-equiv="refresh" content="{remaining}">',
                unsafe_allow_html=True,
            )


def main() -> None:
    sidebar = render_sidebar()
    inject_global_styles(dark_mode=True, project_root=ROOT)
    render_header_bar(_get_last_updated())

    st.markdown('<div class="dashboard-shell">', unsafe_allow_html=True)
    st.markdown(
        '<p class="safety-banner">Educational tool only. Not financial advice. No guaranteed profits.</p>',
        unsafe_allow_html=True,
    )

    if sidebar.analyze_clicked:
        with st.spinner("Fetching market data and running AI analysis..."):
            try:
                _run_analysis(sidebar.symbol, sidebar.interval, sidebar.api_key)
            except Exception as exc:
                render_error_state(str(exc))
                st.markdown("</div>", unsafe_allow_html=True)
                return
        st.rerun()

    if "last_result" not in st.session_state:
        render_empty_state()
        st.markdown("</div>", unsafe_allow_html=True)
        return

    st.session_state["chart_interval"] = "1m"
    render_dashboard(
        st.session_state["last_result"],
        dark=True,
        risk_settings=sidebar.risk_settings,
    )
    st.markdown("</div>", unsafe_allow_html=True)

    _auto_refresh(sidebar.symbol, sidebar.interval, sidebar.api_key)


if __name__ == "__main__":
    main()
```

---

<a id="file-generate_export-py"></a>
## File: `generate_export.py`

```python
"""Regenerate PROJECT_EXPORT.md from all project source files."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "PROJECT_EXPORT.md"

FILES = [
    "requirements.txt",
    ".env.example",
    ".gitignore",
    "README.md",
    "app.py",
    "generate_export.py",
    "assets/README.txt",
    "src/data/__init__.py",
    "src/data/binance_client.py",
    "src/data/cache.py",
    "src/data/coinglass_client.py",
    "src/data/data_hub.py",
    "src/data/fear_greed.py",
    "src/data/hub_models.py",
    "src/data/news_client.py",
    "src/data/news_sentiment.py",
    "src/data/onchain.py",
    "src/data/onchain_client.py",
    "src/data/whale_client.py",
    "src/data/connectors/__init__.py",
    "src/data/connectors/base.py",
    "src/data/connectors/binance_connector.py",
    "src/data/connectors/bybit.py",
    "src/data/connectors/coinbase.py",
    "src/data/connectors/kraken.py",
    "src/data/connectors/okx.py",
    "src/indicators/technical.py",
    "src/analysis/models.py",
    "src/analysis/scorer.py",
    "src/analysis/sentiment.py",
    "src/analysis/risk_manager.py",
    "src/analysis/ai_decision_engine.py",
    "src/ui/__init__.py",
    "src/ui/theme.py",
    "src/ui/time_utils.py",
    "src/ui/helpers.py",
    "src/ui/primitives.py",
    "src/ui/styles.py",
    "src/ui/background.py",
    "src/ui/charts.py",
    "src/ui/sidebar.py",
    "src/ui/dashboard.py",
    "src/ui/components.py",
    "src/ui/tradingview.py",
]

LANG = {
    ".py": "python",
    ".md": "markdown",
    ".txt": "text",
    ".example": "text",
    "": "text",
}


def main() -> None:
    lines: list[str] = [
        "# Ofir Kadosh Bitcoin AI Dashboard — Full Project Export",
        "",
        f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}",
        f"Location: `{ROOT}`",
        "",
        "## Table of Contents",
        "",
    ]

    for rel in FILES:
        anchor = rel.replace("/", "-").replace(".", "-").replace("\\", "-")
        lines.append(f"- [{rel}](#file-{anchor})")

    lines.extend(["", "---", ""])

    for rel in FILES:
        path = ROOT / rel
        if not path.is_file():
            continue
        suffix = path.suffix
        lang = LANG.get(suffix, "text")
        anchor = rel.replace("/", "-").replace(".", "-").replace("\\", "-")
        content = path.read_text(encoding="utf-8").rstrip()

        lines.extend([
            f"<a id=\"file-{anchor}\"></a>",
            f"## File: `{rel}`",
            "",
            f"```{lang}",
            content,
            "```",
            "",
            "---",
            "",
        ])

    OUTPUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {OUTPUT} ({OUTPUT.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
```

---

<a id="file-assets-README-txt"></a>
## File: `assets/README.txt`

```text
# Custom background image
#
# Place your image here as:
#   assets/background.jpg
#
# Supported fallbacks: .jpeg, .png, .webp
#
# The app applies it automatically on every startup with:
#   - full-page cover, centered, no repeat, fixed while scrolling
#   - ~45% dark overlay for readability
#   - glass-style semi-transparent cards
#
# If background.jpg is missing, the default theme is used (no crash).
```

---

<a id="file-src-data-__init__-py"></a>
## File: `src/data/__init__.py`

```python
"""Data layer — unified Bitcoin Data Hub and source connectors."""

from src.data.data_hub import BitcoinDataHub
from src.data.hub_models import HubSnapshot, SourceInfo

__all__ = ["BitcoinDataHub", "HubSnapshot", "SourceInfo"]
```

---

<a id="file-src-data-binance_client-py"></a>
## File: `src/data/binance_client.py`

```python
"""Fetch OHLCV and derivatives data from Binance public APIs."""

from __future__ import annotations

from typing import Any

import pandas as pd
import requests

SPOT_BASE = "https://api.binance.com"
FUTURES_BASE = "https://fapi.binance.com"


class BinanceClient:
    def __init__(self, symbol: str = "BTCUSDT", timeout: int = 15) -> None:
        self.symbol = symbol
        self.timeout = timeout

    def _get(self, base: str, path: str, params: dict[str, Any] | None = None) -> Any:
        url = f"{base}{path}"
        response = requests.get(url, params=params or {}, timeout=self.timeout)
        response.raise_for_status()
        return response.json()

    def get_klines(
        self,
        interval: str = "1h",
        limit: int = 500,
    ) -> pd.DataFrame:
        raw = self._get(
            SPOT_BASE,
            "/api/v3/klines",
            {"symbol": self.symbol, "interval": interval, "limit": limit},
        )
        df = pd.DataFrame(
            raw,
            columns=[
                "open_time",
                "open",
                "high",
                "low",
                "close",
                "volume",
                "close_time",
                "quote_volume",
                "trades",
                "taker_buy_base",
                "taker_buy_quote",
                "ignore",
            ],
        )
        numeric_cols = ["open", "high", "low", "close", "volume", "quote_volume", "taker_buy_base"]
        for col in numeric_cols:
            df[col] = pd.to_numeric(df[col], errors="coerce")
        df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
        df["close_time"] = pd.to_datetime(df["close_time"], unit="ms", utc=True)
        return df

    def get_funding_rate(self) -> float | None:
        try:
            data = self._get(
                FUTURES_BASE,
                "/fapi/v1/premiumIndex",
                {"symbol": self.symbol},
            )
            return float(data.get("lastFundingRate", 0))
        except requests.RequestException:
            return None

    def get_open_interest(self) -> float | None:
        try:
            data = self._get(
                FUTURES_BASE,
                "/fapi/v1/openInterest",
                {"symbol": self.symbol},
            )
            return float(data.get("openInterest", 0))
        except requests.RequestException:
            return None

    def get_long_short_ratio(self, period: str = "1h", limit: int = 30) -> pd.DataFrame | None:
        try:
            raw = self._get(
                FUTURES_BASE,
                "/futures/data/globalLongShortAccountRatio",
                {"symbol": self.symbol, "period": period, "limit": limit},
            )
            df = pd.DataFrame(raw)
            if df.empty:
                return None
            df["longShortRatio"] = pd.to_numeric(df["longShortRatio"], errors="coerce")
            df["longAccount"] = pd.to_numeric(df["longAccount"], errors="coerce")
            df["shortAccount"] = pd.to_numeric(df["shortAccount"], errors="coerce")
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
            return df
        except requests.RequestException:
            return None

    def get_ticker_price(self) -> float:
        data = self._get(SPOT_BASE, "/api/v3/ticker/price", {"symbol": self.symbol})
        return float(data["price"])

    def get_order_book(self, limit: int = 20) -> dict | None:
        try:
            data = self._get(
                SPOT_BASE,
                "/api/v3/depth",
                {"symbol": self.symbol, "limit": limit},
            )
            return {
                "bids": data.get("bids", []),
                "asks": data.get("asks", []),
                "lastUpdateId": data.get("lastUpdateId"),
            }
        except requests.RequestException:
            return None
```

---

<a id="file-src-data-cache-py"></a>
## File: `src/data/cache.py`

```python
"""Simple in-memory TTL cache for API responses."""

from __future__ import annotations

import time
from typing import Any, TypeVar

T = TypeVar("T")


class TTLCache:
    def __init__(self, default_ttl: int = 60) -> None:
        self._default_ttl = default_ttl
        self._store: dict[str, tuple[float, Any]] = {}

    def get(self, key: str) -> Any | None:
        entry = self._store.get(key)
        if entry is None:
            return None
        expires_at, value = entry
        if time.time() >= expires_at:
            del self._store[key]
            return None
        return value

    def set(self, key: str, value: Any, *, ttl: int | None = None) -> None:
        seconds = self._default_ttl if ttl is None else ttl
        self._store[key] = (time.time() + seconds, value)

    def clear(self) -> None:
        self._store.clear()
```

---

<a id="file-src-data-coinglass_client-py"></a>
## File: `src/data/coinglass_client.py`

```python
"""Optional Coinglass API client for derivatives and liquidation heatmap data."""

from __future__ import annotations

import os
from typing import Any

import pandas as pd
import requests

BASE_URL = "https://open-api-v4.coinglass.com"


class CoinglassClient:
    def __init__(self, api_key: str | None = None, timeout: int = 15) -> None:
        self.api_key = api_key or os.getenv("COINGLASS_API_KEY", "").strip()
        self.timeout = timeout
        self.enabled = bool(self.api_key)

    def _headers(self) -> dict[str, str]:
        return {"CG-API-KEY": self.api_key, "accept": "application/json"}

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        if not self.enabled:
            return None
        url = f"{BASE_URL}{path}"
        response = requests.get(
            url,
            headers=self._headers(),
            params=params or {},
            timeout=self.timeout,
        )
        response.raise_for_status()
        payload = response.json()
        if str(payload.get("code")) != "0":
            raise ValueError(payload.get("msg", "Coinglass API error"))
        return payload.get("data")

    def get_funding_rates(self) -> list[dict[str, Any]] | None:
        try:
            data = self._get("/api/futures/funding-rate/exchange-list")
            if not data:
                return None
            for item in data:
                if item.get("symbol") == "BTC":
                    return item.get("stablecoin_margin_list") or []
            return None
        except (requests.RequestException, ValueError):
            return None

    def get_open_interest_history(
        self,
        exchange: str = "Binance",
        interval: str = "1h",
        limit: int = 50,
    ) -> pd.DataFrame | None:
        try:
            data = self._get(
                "/api/futures/open-interest/history",
                {
                    "exchange": exchange,
                    "symbol": "BTCUSDT",
                    "interval": interval,
                    "limit": limit,
                },
            )
            if not data:
                return None
            df = pd.DataFrame(data)
            for col in ("open", "high", "low", "close"):
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors="coerce")
            if "time" in df.columns:
                df["time"] = pd.to_datetime(df["time"], unit="ms", utc=True)
            return df
        except (requests.RequestException, ValueError):
            return None

    def get_liquidation_heatmap(self, range_param: str = "3d") -> dict[str, Any] | None:
        """Fetch liquidation heatmap model2 data when API key is available."""
        try:
            return self._get(
                "/api/futures/liquidation/heatmap/model2",
                {"symbol": "BTC", "range": range_param},
            )
        except (requests.RequestException, ValueError):
            return None

    def get_long_short_ratio_history(
        self,
        interval: str = "1h",
        limit: int = 50,
    ) -> pd.DataFrame | None:
        try:
            data = self._get(
                "/api/futures/global-long-short-account-ratio/history",
                {"symbol": "BTC", "interval": interval, "limit": limit},
            )
            if not data:
                return None
            df = pd.DataFrame(data)
            for col in ("longRate", "shortRate", "longShortRatio"):
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors="coerce")
            if "time" in df.columns:
                df["time"] = pd.to_datetime(df["time"], unit="ms", utc=True)
            return df
        except (requests.RequestException, ValueError):
            return None
```

---

<a id="file-src-data-data_hub-py"></a>
## File: `src/data/data_hub.py`

```python
"""Unified Bitcoin Data Hub — aggregates multi-source market intelligence."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import pandas as pd

from src.data.cache import TTLCache
from src.data.coinglass_client import CoinglassClient
from src.data.connectors import (
    BinanceConnector,
    BybitConnector,
    CoinbaseConnector,
    KrakenConnector,
    OKXConnector,
)
from src.data.hub_models import HubSnapshot, SourceInfo
from src.data.news_sentiment import NewsSentimentProvider
from src.data.onchain import OnChainProvider
from src.indicators.technical import parse_coinglass_heatmap

TRACKED_FIELDS = [
    "price",
    "candles",
    "volume",
    "order_book",
    "funding_rate",
    "open_interest",
    "long_short_ratio",
    "liquidations",
]

CRITICAL_FIELDS = ["price", "candles"]


class BitcoinDataHub:
    """Collects Bitcoin data from trusted sources with graceful degradation."""

    def __init__(
        self,
        *,
        symbol: str = "BTCUSDT",
        coinglass_api_key: str | None = None,
        timeout: int = 15,
        cache_ttl: int = 60,
    ) -> None:
        self.symbol = symbol
        self.timeout = timeout
        self.cache = TTLCache(default_ttl=cache_ttl)
        self.binance = BinanceConnector(symbol=symbol, timeout=timeout)
        self.coinglass = CoinglassClient(api_key=coinglass_api_key, timeout=timeout)
        self.onchain = OnChainProvider()
        self.news_sentiment = NewsSentimentProvider()
        self.alt_connectors = [
            BybitConnector(timeout=timeout),
            OKXConnector(timeout=timeout),
            CoinbaseConnector(timeout=timeout),
            KrakenConnector(timeout=timeout),
        ]

    def fetch(self, *, interval: str = "1h", limit: int = 500, use_cache: bool = True) -> HubSnapshot:
        cache_key = f"{self.symbol}:{interval}:{limit}"
        if use_cache:
            cached = self.cache.get(cache_key)
            if isinstance(cached, HubSnapshot):
                return cached

        snapshot = HubSnapshot(last_updated=datetime.now(timezone.utc))
        self._fetch_binance(snapshot, interval=interval, limit=limit)
        self._fetch_coinglass(snapshot, interval=interval)
        self._fetch_alt_exchanges(snapshot)
        self._fetch_onchain(snapshot)
        self._fetch_news_sentiment(snapshot)
        self._finalize_snapshot(snapshot)

        if use_cache:
            self.cache.set(cache_key, snapshot, ttl=self.cache._default_ttl)
        return snapshot

    def _fetch_binance(self, snapshot: HubSnapshot, *, interval: str, limit: int) -> None:
        probe = self.binance.probe()
        snapshot.source_status[self.binance.name] = probe

        try:
            bundle = self.binance.fetch_market_bundle(interval=interval, limit=limit)
        except Exception as exc:
            snapshot.source_status[self.binance.name] = SourceInfo(
                name=self.binance.name,
                status="offline",
                error=str(exc),
            )
            return

        snapshot.price = bundle.get("price")
        snapshot.candles = bundle.get("candles")
        snapshot.volume = bundle.get("volume")
        snapshot.order_book = bundle.get("order_book")
        snapshot.funding_rate = bundle.get("funding_rate")
        snapshot.open_interest = bundle.get("open_interest")
        snapshot.long_short_ratio = bundle.get("long_short_ratio")

        errors = bundle.get("errors") or []
        status: str = "online"
        if errors and snapshot.price is not None:
            status = "degraded"
        elif snapshot.price is None:
            status = "offline"

        snapshot.source_status[self.binance.name] = SourceInfo(
            name=self.binance.name,
            status=status,  # type: ignore[arg-type]
            last_updated=datetime.now(timezone.utc) if snapshot.price is not None else None,
            error="; ".join(errors) if errors else None,
            fields=[field for field in TRACKED_FIELDS if getattr(snapshot, field, None) is not None],
        )
        if snapshot.price is not None and self.binance.name not in snapshot.sources:
            snapshot.sources.append(self.binance.name)

    def _fetch_coinglass(self, snapshot: HubSnapshot, *, interval: str) -> None:
        if not self.coinglass.enabled:
            snapshot.source_status["Coinglass"] = SourceInfo(
                name="Coinglass",
                status="offline",
                error="API key not configured",
                fields=[],
            )
            return

        errors: list[str] = []
        fields: list[str] = []
        liquidation_payload: dict[str, Any] = {"heatmap": None, "source": "Coinglass"}

        try:
            oi_hist = self.coinglass.get_open_interest_history(interval=interval)
            if oi_hist is not None and len(oi_hist) >= 2 and "close" in oi_hist.columns:
                latest_oi = oi_hist.iloc[-1]["close"]
                prev_oi = oi_hist.iloc[-2]["close"]
                snapshot.open_interest = float(latest_oi)
                fields.append("open_interest")
                if prev_oi:
                    snapshot.open_interest_change_pct = ((latest_oi - prev_oi) / prev_oi) * 100
                    fields.append("open_interest_change_pct")
        except Exception as exc:
            errors.append(f"open_interest: {exc}")

        try:
            cg_funding = self.coinglass.get_funding_rates()
            if cg_funding:
                for entry in cg_funding:
                    if entry.get("exchange") == "Binance":
                        snapshot.funding_rate = float(entry.get("funding_rate", snapshot.funding_rate or 0))
                        fields.append("funding_rate")
                        break
        except Exception as exc:
            errors.append(f"funding_rate: {exc}")

        try:
            cg_ls = self.coinglass.get_long_short_ratio_history(interval=interval, limit=2)
            if cg_ls is not None and not cg_ls.empty and "longShortRatio" in cg_ls.columns:
                snapshot.long_short_ratio = float(cg_ls.iloc[-1]["longShortRatio"])
                fields.append("long_short_ratio")
        except Exception as exc:
            errors.append(f"long_short_ratio: {exc}")

        try:
            raw_heatmap = self.coinglass.get_liquidation_heatmap()
            parsed = parse_coinglass_heatmap(raw_heatmap, snapshot.price or 0.0)
            liquidation_payload["heatmap_rows"] = 0 if parsed is None else len(parsed)
            liquidation_payload["heatmap"] = "available" if parsed is not None else None
            snapshot.liquidations = liquidation_payload
            if parsed is not None:
                fields.append("liquidations")
        except Exception as exc:
            errors.append(f"liquidations: {exc}")
            snapshot.liquidations = liquidation_payload

        status = "online" if fields else "degraded"
        if errors and not fields:
            status = "offline"

        snapshot.source_status["Coinglass"] = SourceInfo(
            name="Coinglass",
            status=status,  # type: ignore[arg-type]
            last_updated=datetime.now(timezone.utc) if fields else None,
            error="; ".join(errors) if errors else None,
            fields=fields,
        )
        if fields and "Coinglass" not in snapshot.sources:
            snapshot.sources.append("Coinglass")

    def _fetch_alt_exchanges(self, snapshot: HubSnapshot) -> None:
        for connector in self.alt_connectors:
            info = connector.probe()
            snapshot.source_status[connector.name] = info

    def _fetch_onchain(self, snapshot: HubSnapshot) -> None:
        try:
            payload, info = self.onchain.fetch()
            snapshot.onchain = payload
            snapshot.source_status[info.name] = info
        except Exception as exc:
            snapshot.onchain = {}
            snapshot.source_status["On-Chain"] = SourceInfo(
                name="On-Chain",
                status="offline",
                error=str(exc),
            )

    def _fetch_news_sentiment(self, snapshot: HubSnapshot) -> None:
        try:
            news, sentiment, info = self.news_sentiment.fetch()
            snapshot.news = news
            snapshot.sentiment = sentiment
            snapshot.source_status[info.name] = info
        except Exception as exc:
            snapshot.news = {}
            snapshot.sentiment = {}
            snapshot.source_status["News & Sentiment"] = SourceInfo(
                name="News & Sentiment",
                status="offline",
                error=str(exc),
            )

    def _finalize_snapshot(self, snapshot: HubSnapshot) -> None:
        available: list[str] = []
        missing: list[str] = []

        for field in TRACKED_FIELDS:
            value = getattr(snapshot, field, None)
            if field == "candles":
                ok = isinstance(value, pd.DataFrame) and not value.empty
            elif field == "liquidations":
                ok = isinstance(value, dict) and value.get("heatmap") == "available"
            else:
                ok = value is not None
            if ok:
                available.append(field)
            else:
                missing.append(field)

        snapshot.available_fields = available
        snapshot.missing_fields = missing
        snapshot.critical_missing = any(field in missing for field in CRITICAL_FIELDS)
        snapshot.force_wait = snapshot.critical_missing

        if snapshot.critical_missing:
            snapshot.data_quality = "critical"
            snapshot.confidence_impact = "critical — WAIT recommended"
        elif len(missing) >= 4:
            snapshot.data_quality = "partial"
            snapshot.confidence_impact = "high — confidence reduced"
        elif missing:
            snapshot.data_quality = "partial"
            snapshot.confidence_impact = "moderate — some inputs missing"
        else:
            snapshot.data_quality = "full"
            snapshot.confidence_impact = "none"

        snapshot.last_updated = datetime.now(timezone.utc)
```

---

<a id="file-src-data-fear_greed-py"></a>
## File: `src/data/fear_greed.py`

```python
"""Fear & Greed Index client (Alternative.me)."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import requests

from src.data.hub_models import SourceInfo

FNG_URL = "https://api.alternative.me/fng/"


class FearGreedClient:
    name = "Fear & Greed"

    def __init__(self, timeout: float = 10.0) -> None:
        self.timeout = timeout

    def fetch(self, limit: int = 1) -> tuple[dict[str, Any], SourceInfo]:
        try:
            response = requests.get(
                FNG_URL,
                params={"limit": limit, "format": "json"},
                timeout=self.timeout,
            )
            response.raise_for_status()
            payload = response.json()
            entries = payload.get("data") or []
            if not entries:
                raise ValueError("Empty Fear & Greed response")

            latest = entries[0]
            value = int(latest.get("value", 0))
            classification = str(latest.get("value_classification", "Unknown"))
            timestamp = latest.get("timestamp")

            data = {
                "status": "online",
                "value": value,
                "classification": classification,
                "timestamp": timestamp,
                "provider": "Alternative.me",
            }
            info = SourceInfo(
                name=self.name,
                status="online",
                last_updated=datetime.now(timezone.utc),
                fields=["fear_greed_index"],
            )
            return data, info
        except Exception as exc:
            data = {
                "status": "offline",
                "value": None,
                "classification": None,
                "provider": "Alternative.me",
                "error": str(exc),
            }
            info = SourceInfo(
                name=self.name,
                status="offline",
                last_updated=datetime.now(timezone.utc),
                error=str(exc),
                fields=["fear_greed_index"],
            )
            return data, info
```

---

<a id="file-src-data-hub_models-py"></a>
## File: `src/data/hub_models.py`

```python
"""Data structures for the unified Bitcoin Data Hub."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Literal

import pandas as pd

SourceStatus = Literal["online", "offline", "degraded", "placeholder"]


@dataclass
class SourceInfo:
    name: str
    status: SourceStatus
    last_updated: datetime | None = None
    error: str | None = None
    fields: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status,
            "last_updated": self.last_updated.isoformat() if self.last_updated else None,
            "error": self.error,
            "fields": self.fields,
        }


@dataclass
class HubSnapshot:
    price: float | None = None
    candles: pd.DataFrame | None = None
    volume: float | None = None
    order_book: dict[str, Any] | None = None
    funding_rate: float | None = None
    open_interest: float | None = None
    open_interest_change_pct: float | None = None
    long_short_ratio: float | None = None
    liquidations: dict[str, Any] | None = None
    onchain: dict[str, Any] = field(default_factory=dict)
    news: dict[str, Any] = field(default_factory=dict)
    sentiment: dict[str, Any] = field(default_factory=dict)
    sources: list[str] = field(default_factory=list)
    source_status: dict[str, SourceInfo] = field(default_factory=dict)
    last_updated: datetime | None = None
    missing_fields: list[str] = field(default_factory=list)
    available_fields: list[str] = field(default_factory=list)
    data_quality: str = "partial"
    confidence_impact: str = "none"
    critical_missing: bool = False
    force_wait: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "price": self.price,
            "candles": None if self.candles is None else f"{len(self.candles)} rows",
            "volume": self.volume,
            "order_book": self.order_book,
            "funding_rate": self.funding_rate,
            "open_interest": self.open_interest,
            "open_interest_change_pct": self.open_interest_change_pct,
            "long_short_ratio": self.long_short_ratio,
            "liquidations": self.liquidations,
            "onchain": self.onchain,
            "news": self.news,
            "sentiment": self.sentiment,
            "sources": self.sources,
            "source_status": {k: v.to_dict() for k, v in self.source_status.items()},
            "last_updated": self.last_updated.isoformat() if self.last_updated else None,
            "missing_fields": self.missing_fields,
            "available_fields": self.available_fields,
            "data_quality": self.data_quality,
            "confidence_impact": self.confidence_impact,
            "critical_missing": self.critical_missing,
            "force_wait": self.force_wait,
        }
```

---

<a id="file-src-data-news_client-py"></a>
## File: `src/data/news_client.py`

```python
"""Crypto news RSS client with simple headline sentiment."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

try:
    import feedparser
except ImportError:
    feedparser = None

from src.analysis.sentiment import analyze_headline_sentiment, summarize_sentiment
from src.data.hub_models import SourceInfo

RSS_FEEDS: dict[str, str] = {
    "CoinDesk": "https://www.coindesk.com/arc/outboundfeeds/rss/",
    "Cointelegraph": "https://cointelegraph.com/rss",
    "Bitcoin Magazine": "https://bitcoinmagazine.com/.rss/full/",
}


class NewsClient:
    name = "News RSS"

    def __init__(self, timeout: float = 12.0, max_items: int = 15) -> None:
        self.timeout = timeout
        self.max_items = max_items

    def fetch(self) -> tuple[dict[str, Any], SourceInfo]:
        headlines: list[dict[str, Any]] = []
        errors: list[str] = []

        if feedparser is None:
            data = {
                "status": "offline",
                "headlines": [],
                "summary": summarize_sentiment([]),
                "error": "feedparser not installed",
            }
            info = SourceInfo(
                name=self.name,
                status="offline",
                last_updated=datetime.now(timezone.utc),
                error="feedparser not installed",
                fields=["headlines", "sentiment"],
            )
            return data, info

        for source, url in RSS_FEEDS.items():
            try:
                parsed = feedparser.parse(url, request_headers={"User-Agent": "btc-market-analyzer/1.0"})
                for entry in (parsed.entries or [])[: self.max_items // len(RSS_FEEDS) + 3]:
                    title = str(getattr(entry, "title", "") or "").strip()
                    if not title:
                        continue
                    sentiment = analyze_headline_sentiment(title)
                    headlines.append(
                        {
                            "source": source,
                            "title": title,
                            "link": getattr(entry, "link", ""),
                            "sentiment": sentiment,
                        }
                    )
            except Exception as exc:
                errors.append(f"{source}: {exc}")

        headlines = headlines[: self.max_items]
        summary = summarize_sentiment(headlines)

        if headlines:
            status = "online"
            source_status = "online"
            error = "; ".join(errors) if errors else None
        else:
            status = "offline"
            source_status = "offline"
            error = "; ".join(errors) if errors else "No headlines fetched"

        data = {
            "status": status,
            "headlines": headlines,
            "summary": summary,
            "feeds": list(RSS_FEEDS.keys()),
            "error": error,
        }
        info = SourceInfo(
            name=self.name,
            status=source_status,
            last_updated=datetime.now(timezone.utc),
            error=error if source_status != "online" else None,
            fields=["headlines", "sentiment"],
        )
        return data, info
```

---

<a id="file-src-data-news_sentiment-py"></a>
## File: `src/data/news_sentiment.py`

```python
"""News and sentiment placeholders for future API integrations."""

from __future__ import annotations

from datetime import datetime, timezone

from src.data.hub_models import SourceInfo


class NewsSentimentProvider:
    name = "News & Sentiment"

    def fetch(self) -> tuple[dict, dict, SourceInfo]:
        news = {
            "headlines": {"status": "placeholder", "items": [], "provider": "future crypto news API"},
            "macro_events": {"status": "placeholder", "items": [], "provider": "future macro calendar API"},
        }
        sentiment = {
            "fear_greed_index": {"status": "placeholder", "value": None, "provider": "future Fear & Greed API"},
            "social_sentiment": {"status": "placeholder", "value": None, "provider": "future social sentiment API"},
        }
        info = SourceInfo(
            name=self.name,
            status="placeholder",
            last_updated=datetime.now(timezone.utc),
            error="News and sentiment APIs not yet connected",
            fields=["headlines", "macro_events", "fear_greed_index", "social_sentiment"],
        )
        return news, sentiment, info
```

---

<a id="file-src-data-onchain-py"></a>
## File: `src/data/onchain.py`

```python
"""On-chain data placeholders for future API integrations."""

from __future__ import annotations

from datetime import datetime, timezone

from src.data.hub_models import SourceInfo


class OnChainProvider:
    name = "On-Chain"

    def fetch(self) -> tuple[dict, SourceInfo]:
        payload = {
            "exchange_inflows": {"status": "placeholder", "value": None, "provider": "future API"},
            "exchange_outflows": {"status": "placeholder", "value": None, "provider": "future API"},
            "whale_transactions": {"status": "placeholder", "value": None, "provider": "future API"},
            "active_addresses": {"status": "placeholder", "value": None, "provider": "future API"},
            "miner_flows": {"status": "placeholder", "value": None, "provider": "future API"},
            "stablecoin_flows": {"status": "placeholder", "value": None, "provider": "future API"},
        }
        info = SourceInfo(
            name=self.name,
            status="placeholder",
            last_updated=datetime.now(timezone.utc),
            error="On-chain APIs not yet connected",
            fields=list(payload.keys()),
        )
        return payload, info
```

---

<a id="file-src-data-onchain_client-py"></a>
## File: `src/data/onchain_client.py`

```python
"""On-chain data client with optional API key providers."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any

import requests

from src.data.hub_models import SourceInfo

SUPPORTED_PROVIDERS = ("Glassnode", "CryptoQuant", "Arkham")


class OnChainClient:
    name = "On-Chain"

    def __init__(self, timeout: float = 10.0) -> None:
        self.timeout = timeout
        self.glassnode_key = os.getenv("GLASSNODE_API_KEY", "").strip()
        self.cryptoquant_key = os.getenv("CRYPTOQUANT_API_KEY", "").strip()
        self.arkham_key = os.getenv("ARKHAM_API_KEY", "").strip()

    def fetch(self) -> tuple[dict[str, Any], SourceInfo]:
        payload: dict[str, Any] = {
            "exchange_inflows": self._field("Glassnode", self.glassnode_key),
            "exchange_outflows": self._field("Glassnode", self.glassnode_key),
            "active_addresses": self._field("Glassnode", self.glassnode_key),
            "miner_flows": self._field("CryptoQuant", self.cryptoquant_key),
            "stablecoin_flows": self._field("CryptoQuant", self.cryptoquant_key),
            "entity_labels": self._field("Arkham", self.arkham_key),
        }

        has_key = any([self.glassnode_key, self.cryptoquant_key, self.arkham_key])
        if has_key:
            payload = self._try_fetch_live(payload)

        if has_key and any(v.get("status") == "online" for v in payload.values()):
            status = "online"
            error = None
        elif has_key:
            status = "offline"
            error = "API keys present but live on-chain fetch failed or unsupported"
        else:
            status = "placeholder"
            error = "Unavailable — add API key (GLASSNODE_API_KEY, CRYPTOQUANT_API_KEY, ARKHAM_API_KEY)"

        info = SourceInfo(
            name=self.name,
            status=status,
            last_updated=datetime.now(timezone.utc),
            error=error,
            fields=list(payload.keys()),
        )
        return payload, info

    @staticmethod
    def _field(provider: str, api_key: str) -> dict[str, Any]:
        if not api_key:
            return {
                "status": "unavailable",
                "value": None,
                "provider": provider,
                "message": "Unavailable — add API key",
            }
        return {
            "status": "pending",
            "value": None,
            "provider": provider,
            "message": f"{provider} key detected — live endpoint not wired yet",
        }

    def _try_fetch_live(self, payload: dict[str, Any]) -> dict[str, Any]:
        if self.glassnode_key:
            try:
                response = requests.get(
                    "https://api.glassnode.com/v1/metrics/addresses/active_count",
                    params={"a": "BTC", "api_key": self.glassnode_key, "i": "24h"},
                    timeout=self.timeout,
                )
                if response.status_code == 200:
                    data = response.json()
                    if data:
                        payload["active_addresses"] = {
                            "status": "online",
                            "value": data[-1].get("v"),
                            "provider": "Glassnode",
                        }
            except Exception:
                pass
        return payload
```

---

<a id="file-src-data-whale_client-py"></a>
## File: `src/data/whale_client.py`

```python
"""Whale activity client with optional API key providers."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any

from src.data.hub_models import SourceInfo

SUPPORTED_PROVIDERS = ("Whale Alert", "Glassnode", "CryptoQuant", "Arkham")


class WhaleClient:
    name = "Whale Data"

    def __init__(self, timeout: float = 10.0) -> None:
        self.timeout = timeout
        self.whale_alert_key = os.getenv("WHALE_ALERT_API_KEY", "").strip()
        self.glassnode_key = os.getenv("GLASSNODE_API_KEY", "").strip()
        self.cryptoquant_key = os.getenv("CRYPTOQUANT_API_KEY", "").strip()
        self.arkham_key = os.getenv("ARKHAM_API_KEY", "").strip()

    def fetch(self) -> tuple[dict[str, Any], SourceInfo]:
        payload = {
            "large_transfers": self._provider_block("Whale Alert", self.whale_alert_key),
            "exchange_whale_inflow": self._provider_block("CryptoQuant", self.cryptoquant_key),
            "exchange_whale_outflow": self._provider_block("CryptoQuant", self.cryptoquant_key),
            "labeled_wallets": self._provider_block("Arkham", self.arkham_key),
            "whale_accumulation": self._provider_block("Glassnode", self.glassnode_key),
        }

        has_key = any([self.whale_alert_key, self.glassnode_key, self.cryptoquant_key, self.arkham_key])
        if has_key:
            status = "placeholder"
            error = "API keys detected — whale endpoints prepared but not fully wired"
        else:
            status = "placeholder"
            error = "Unavailable — add API key (WHALE_ALERT_API_KEY, GLASSNODE_API_KEY, etc.)"

        info = SourceInfo(
            name=self.name,
            status=status,
            last_updated=datetime.now(timezone.utc),
            error=error,
            fields=list(payload.keys()),
        )
        return payload, info

    @staticmethod
    def _provider_block(provider: str, api_key: str) -> dict[str, Any]:
        if not api_key:
            return {
                "status": "unavailable",
                "value": None,
                "provider": provider,
                "message": "Unavailable — add API key",
            }
        return {
            "status": "pending",
            "value": None,
            "provider": provider,
            "message": f"{provider} key detected — awaiting live integration",
        }
```

---

<a id="file-src-data-connectors-__init__-py"></a>
## File: `src/data/connectors/__init__.py`

```python
"""Exchange and data source connectors."""

from src.data.connectors.base import BaseConnector
from src.data.connectors.binance_connector import BinanceConnector
from src.data.connectors.bybit import BybitConnector
from src.data.connectors.coinbase import CoinbaseConnector
from src.data.connectors.kraken import KrakenConnector
from src.data.connectors.okx import OKXConnector

__all__ = [
    "BaseConnector",
    "BinanceConnector",
    "BybitConnector",
    "OKXConnector",
    "CoinbaseConnector",
    "KrakenConnector",
]
```

---

<a id="file-src-data-connectors-base-py"></a>
## File: `src/data/connectors/base.py`

```python
"""Base connector with timeout-safe API calls."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any, Callable, TypeVar

from src.data.hub_models import SourceInfo, SourceStatus

T = TypeVar("T")


class BaseConnector(ABC):
    name: str = "base"
    enabled: bool = False

    def __init__(self, timeout: int = 15) -> None:
        self.timeout = timeout

    @abstractmethod
    def probe(self) -> SourceInfo:
        """Return connector availability without heavy fetching."""

    def safe_call(self, label: str, fn: Callable[[], T], default: T | None = None) -> tuple[T | None, str | None]:
        try:
            return fn(), None
        except Exception as exc:
            return default, f"{label}: {exc}"

    def _info(
        self,
        *,
        status: SourceStatus,
        fields: list[str] | None = None,
        error: str | None = None,
    ) -> SourceInfo:
        return SourceInfo(
            name=self.name,
            status=status,
            last_updated=datetime.now(timezone.utc) if status == "online" else None,
            error=error,
            fields=fields or [],
        )
```

---

<a id="file-src-data-connectors-binance_connector-py"></a>
## File: `src/data/connectors/binance_connector.py`

```python
"""Primary Binance market-data connector."""

from __future__ import annotations

from typing import Any

import pandas as pd

from src.data.binance_client import BinanceClient
from src.data.connectors.base import BaseConnector
from src.data.hub_models import SourceInfo


class BinanceConnector(BaseConnector):
    name = "Binance"
    enabled = True

    def __init__(self, symbol: str = "BTCUSDT", timeout: int = 15) -> None:
        super().__init__(timeout=timeout)
        self.symbol = symbol
        self.client = BinanceClient(symbol=symbol, timeout=timeout)

    def probe(self) -> SourceInfo:
        price, error = self.safe_call("price", self.client.get_ticker_price)
        if price is None:
            return self._info(status="offline", error=error)
        return self._info(
            status="online",
            fields=["price", "candles", "volume", "order_book", "funding_rate", "open_interest", "long_short_ratio"],
        )

    def fetch_market_bundle(self, interval: str, limit: int = 500) -> dict[str, Any]:
        bundle: dict[str, Any] = {
            "price": None,
            "candles": None,
            "volume": None,
            "order_book": None,
            "funding_rate": None,
            "open_interest": None,
            "long_short_ratio": None,
            "errors": [],
        }

        price, err = self.safe_call("price", self.client.get_ticker_price)
        bundle["price"] = price
        if err:
            bundle["errors"].append(err)

        candles, err = self.safe_call("candles", lambda: self.client.get_klines(interval=interval, limit=limit))
        bundle["candles"] = candles
        if err:
            bundle["errors"].append(err)
        elif isinstance(candles, pd.DataFrame) and not candles.empty:
            bundle["volume"] = float(candles.iloc[-1]["volume"])

        order_book, err = self.safe_call("order_book", lambda: self.client.get_order_book(limit=20))
        bundle["order_book"] = order_book
        if err:
            bundle["errors"].append(err)

        funding, err = self.safe_call("funding_rate", self.client.get_funding_rate)
        bundle["funding_rate"] = funding
        if err:
            bundle["errors"].append(err)

        oi, err = self.safe_call("open_interest", self.client.get_open_interest)
        bundle["open_interest"] = oi
        if err:
            bundle["errors"].append(err)

        ls_df, err = self.safe_call(
            "long_short_ratio",
            lambda: self.client.get_long_short_ratio(period=interval),
        )
        if isinstance(ls_df, pd.DataFrame) and not ls_df.empty:
            bundle["long_short_ratio"] = float(ls_df.iloc[-1]["longShortRatio"])
        elif err:
            bundle["errors"].append(err)

        return bundle
```

---

<a id="file-src-data-connectors-bybit-py"></a>
## File: `src/data/connectors/bybit.py`

```python
"""Bybit connector placeholder — future multi-exchange support."""

from __future__ import annotations

from src.data.connectors.base import BaseConnector
from src.data.hub_models import SourceInfo


class BybitConnector(BaseConnector):
    name = "Bybit"
    enabled = False

    def probe(self) -> SourceInfo:
        return self._info(
            status="placeholder",
            fields=["price", "candles", "funding_rate", "open_interest"],
            error="Connector placeholder — API integration pending",
        )

    def fetch_snapshot(self) -> dict:
        return {
            "status": "placeholder",
            "message": "Bybit connector not yet connected",
            "fields": ["price", "candles", "funding_rate", "open_interest"],
        }
```

---

<a id="file-src-data-connectors-coinbase-py"></a>
## File: `src/data/connectors/coinbase.py`

```python
"""Coinbase connector placeholder — future multi-exchange support."""

from __future__ import annotations

from src.data.connectors.base import BaseConnector
from src.data.hub_models import SourceInfo


class CoinbaseConnector(BaseConnector):
    name = "Coinbase"
    enabled = False

    def probe(self) -> SourceInfo:
        return self._info(
            status="placeholder",
            fields=["price", "candles", "volume"],
            error="Connector placeholder — API integration pending",
        )

    def fetch_snapshot(self) -> dict:
        return {
            "status": "placeholder",
            "message": "Coinbase connector not yet connected",
            "fields": ["price", "candles", "volume"],
        }
```

---

<a id="file-src-data-connectors-kraken-py"></a>
## File: `src/data/connectors/kraken.py`

```python
"""Kraken connector placeholder — future multi-exchange support."""

from __future__ import annotations

from src.data.connectors.base import BaseConnector
from src.data.hub_models import SourceInfo


class KrakenConnector(BaseConnector):
    name = "Kraken"
    enabled = False

    def probe(self) -> SourceInfo:
        return self._info(
            status="placeholder",
            fields=["price", "candles", "volume"],
            error="Connector placeholder — API integration pending",
        )

    def fetch_snapshot(self) -> dict:
        return {
            "status": "placeholder",
            "message": "Kraken connector not yet connected",
            "fields": ["price", "candles", "volume"],
        }
```

---

<a id="file-src-data-connectors-okx-py"></a>
## File: `src/data/connectors/okx.py`

```python
"""OKX connector placeholder — future multi-exchange support."""

from __future__ import annotations

from src.data.connectors.base import BaseConnector
from src.data.hub_models import SourceInfo


class OKXConnector(BaseConnector):
    name = "OKX"
    enabled = False

    def probe(self) -> SourceInfo:
        return self._info(
            status="placeholder",
            fields=["price", "candles", "funding_rate", "open_interest"],
            error="Connector placeholder — API integration pending",
        )

    def fetch_snapshot(self) -> dict:
        return {
            "status": "placeholder",
            "message": "OKX connector not yet connected",
            "fields": ["price", "candles", "funding_rate", "open_interest"],
        }
```

---

<a id="file-src-indicators-technical-py"></a>
## File: `src/indicators/technical.py`

```python
"""Technical indicator calculations."""

from __future__ import annotations

import numpy as np
import pandas as pd


def ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()


def compute_emas(df: pd.DataFrame, periods: tuple[int, ...] = (9, 21, 50, 200)) -> pd.DataFrame:
    out = df.copy()
    for period in periods:
        out[f"ema_{period}"] = ema(out["close"], period)
    return out


def compute_macd(
    df: pd.DataFrame,
    fast: int = 12,
    slow: int = 26,
    signal: int = 9,
) -> pd.DataFrame:
    out = df.copy()
    ema_fast = ema(out["close"], fast)
    ema_slow = ema(out["close"], slow)
    out["macd"] = ema_fast - ema_slow
    out["macd_signal"] = ema(out["macd"], signal)
    out["macd_hist"] = out["macd"] - out["macd_signal"]
    return out


def compute_rsi(df: pd.DataFrame, period: int = 14) -> pd.DataFrame:
    out = df.copy()
    delta = out["close"].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    out["rsi"] = 100 - (100 / (1 + rs))
    return out


def compute_volume_metrics(df: pd.DataFrame, lookback: int = 20) -> pd.DataFrame:
    out = df.copy()
    out["volume_sma"] = out["volume"].rolling(lookback).mean()
    out["volume_ratio"] = out["volume"] / out["volume_sma"]
    out["taker_buy_ratio"] = out["taker_buy_base"] / out["volume"].replace(0, np.nan)
    return out


def build_volume_heatmap(
    df: pd.DataFrame,
    bins: int = 30,
    lookback: int = 120,
) -> pd.DataFrame:
    """Price-volume profile used as a heatmap proxy when Coinglass is unavailable."""
    window = df.tail(lookback)
    price_min = window["low"].min()
    price_max = window["high"].max()
    if price_min >= price_max:
        price_max = price_min * 1.001

    edges = np.linspace(price_min, price_max, bins + 1)
    midpoints = (edges[:-1] + edges[1:]) / 2
    volumes = np.zeros(bins)

    for _, row in window.iterrows():
        low_idx = np.searchsorted(edges, row["low"], side="right") - 1
        high_idx = np.searchsorted(edges, row["high"], side="left")
        low_idx = max(0, min(bins - 1, low_idx))
        high_idx = max(0, min(bins - 1, high_idx))
        span = max(1, high_idx - low_idx + 1)
        share = row["volume"] / span
        for idx in range(low_idx, high_idx + 1):
            volumes[idx] += share

    heatmap = pd.DataFrame({"price_level": midpoints, "volume": volumes})
    heatmap["intensity"] = heatmap["volume"] / heatmap["volume"].max() if heatmap["volume"].max() else 0
    return heatmap.sort_values("price_level")


def parse_coinglass_heatmap(raw: dict | list | None, current_price: float) -> pd.DataFrame | None:
    """Normalize Coinglass heatmap payloads into price/intensity rows."""
    if not raw:
        return None

    rows: list[dict[str, float]] = []

    if isinstance(raw, dict):
        price_list = raw.get("prices") or raw.get("y") or raw.get("priceList")
        liq_list = raw.get("liquidationLeverage") or raw.get("data") or raw.get("values")
        if isinstance(price_list, list) and isinstance(liq_list, list):
            for price, intensity in zip(price_list, liq_list, strict=False):
                try:
                    rows.append({"price_level": float(price), "intensity": float(intensity)})
                except (TypeError, ValueError):
                    continue
        elif "list" in raw and isinstance(raw["list"], list):
            for item in raw["list"]:
                if not isinstance(item, dict):
                    continue
                price = item.get("price") or item.get("priceLevel")
                intensity = item.get("amount") or item.get("value") or item.get("liquidation")
                if price is not None and intensity is not None:
                    rows.append({"price_level": float(price), "intensity": float(intensity)})

    if isinstance(raw, list):
        for item in raw:
            if not isinstance(item, dict):
                continue
            price = item.get("price") or item.get("priceLevel")
            intensity = item.get("amount") or item.get("value") or item.get("liquidation")
            if price is not None and intensity is not None:
                rows.append({"price_level": float(price), "intensity": float(intensity)})

    if not rows:
        return None

    df = pd.DataFrame(rows)
    max_intensity = df["intensity"].max()
    if max_intensity:
        df["intensity"] = df["intensity"] / max_intensity
    df["distance_pct"] = ((df["price_level"] - current_price) / current_price) * 100
    return df.sort_values("price_level")
```

---

<a id="file-src-analysis-models-py"></a>
## File: `src/analysis/models.py`

```python
"""Analysis result data structures."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

import pandas as pd

Recommendation = Literal["long", "short", "wait"]


@dataclass
class ComponentScore:
    name: str
    score: float
    weight: float
    detail: str


@dataclass
class MarketStatusPanel:
    trend: str
    volatility: str
    liquidity: str


@dataclass
class TradeQuality:
    grade: str
    score: int
    stars: int


@dataclass
class DashboardInsights:
    market_status: MarketStatusPanel
    trade_quality: TradeQuality
    fear_greed: dict[str, Any] = field(default_factory=dict)
    news_sentiment: dict[str, Any] = field(default_factory=dict)
    onchain_data: dict[str, Any] = field(default_factory=dict)
    whale_data: dict[str, Any] = field(default_factory=dict)
    source_status: dict[str, Any] = field(default_factory=dict)


@dataclass
class AnalysisResult:
    symbol: str
    price: float
    score: float
    recommendation: Recommendation
    confidence: str
    stop_loss: float
    take_profit: float
    risk_reward: float
    explanation: str
    components: list[ComponentScore] = field(default_factory=list)
    indicators: dict = field(default_factory=dict)
    heatmap_source: str = "volume_profile"
    data_sources: list[str] = field(default_factory=list)
    heatmap: pd.DataFrame | None = None
    hub: dict | None = None
    supported_sources: list[str] = field(default_factory=list)
    data_quality: str = "full"
    insights: DashboardInsights | None = None
    take_profits: dict[str, float] = field(default_factory=dict)
    risk_profile: dict[str, float] = field(default_factory=dict)
    reasons_enter: list[str] = field(default_factory=list)
    reasons_avoid: list[str] = field(default_factory=list)
    fear_greed: dict[str, Any] = field(default_factory=dict)
    news_sentiment: dict[str, Any] = field(default_factory=dict)
    onchain_data: dict[str, Any] = field(default_factory=dict)
    whale_data: dict[str, Any] = field(default_factory=dict)
    source_status: dict[str, Any] = field(default_factory=dict)
    enhanced_explanation: str = ""
```

---

<a id="file-src-analysis-scorer-py"></a>
## File: `src/analysis/scorer.py`

```python
"""Composite scoring engine for Bitcoin market analysis."""

from __future__ import annotations

import pandas as pd

from src.analysis.models import AnalysisResult, ComponentScore, Recommendation
from src.data.data_hub import BitcoinDataHub
from src.data.hub_models import HubSnapshot
from src.indicators.technical import (
    build_volume_heatmap,
    compute_emas,
    compute_macd,
    compute_rsi,
    compute_volume_metrics,
    parse_coinglass_heatmap,
)


def _clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))


def _score_ema_trend(df: pd.DataFrame) -> ComponentScore:
    latest = df.iloc[-1]
    price = latest["close"]
    ema9 = latest.get("ema_9")
    ema21 = latest.get("ema_21")
    ema50 = latest.get("ema_50")
    ema200 = latest.get("ema_200")

    score = 50.0
    details: list[str] = []

    if pd.notna(ema9) and pd.notna(ema21):
        if ema9 > ema21:
            score += 12
            details.append("EMA9 above EMA21 (short-term bullish)")
        else:
            score -= 12
            details.append("EMA9 below EMA21 (short-term bearish)")

    if pd.notna(ema50) and pd.notna(ema200):
        if ema50 > ema200:
            score += 18
            details.append("EMA50 above EMA200 (primary uptrend)")
        else:
            score -= 18
            details.append("EMA50 below EMA200 (primary downtrend)")

    if pd.notna(ema21):
        if price > ema21:
            score += 8
            details.append("Price trading above EMA21")
        else:
            score -= 8
            details.append("Price trading below EMA21")

    return ComponentScore(
        name="EMA Trend",
        score=_clamp(score),
        weight=0.25,
        detail="; ".join(details),
    )


def _score_macd(df: pd.DataFrame) -> ComponentScore:
    latest = df.iloc[-1]
    prev = df.iloc[-2]
    macd = latest.get("macd")
    signal = latest.get("macd_signal")
    hist = latest.get("macd_hist")
    prev_hist = prev.get("macd_hist")

    score = 50.0
    details: list[str] = []

    if pd.notna(macd) and pd.notna(signal):
        if macd > signal:
            score += 15
            details.append("MACD line above signal line")
        else:
            score -= 15
            details.append("MACD line below signal line")

    if pd.notna(hist):
        if hist > 0:
            score += 10
            details.append("Positive MACD histogram")
        else:
            score -= 10
            details.append("Negative MACD histogram")

    if pd.notna(hist) and pd.notna(prev_hist):
        if hist > prev_hist:
            score += 8
            details.append("MACD momentum improving")
        else:
            score -= 8
            details.append("MACD momentum weakening")

    return ComponentScore(
        name="MACD",
        score=_clamp(score),
        weight=0.20,
        detail="; ".join(details),
    )


def _score_rsi(df: pd.DataFrame) -> ComponentScore:
    rsi = df.iloc[-1].get("rsi")
    score = 50.0
    details: list[str] = []

    if pd.isna(rsi):
        return ComponentScore(name="RSI", score=50.0, weight=0.15, detail="RSI unavailable")

    if rsi >= 70:
        score = 25
        details.append(f"RSI overbought at {rsi:.1f}")
    elif rsi <= 30:
        score = 75
        details.append(f"RSI oversold at {rsi:.1f}")
    elif rsi >= 55:
        score = 65
        details.append(f"RSI bullish zone at {rsi:.1f}")
    elif rsi <= 45:
        score = 35
        details.append(f"RSI bearish zone at {rsi:.1f}")
    else:
        score = 50
        details.append(f"RSI neutral at {rsi:.1f}")

    return ComponentScore(
        name="RSI",
        score=_clamp(score),
        weight=0.15,
        detail="; ".join(details),
    )


def _score_volume(df: pd.DataFrame) -> ComponentScore:
    latest = df.iloc[-1]
    vol_ratio = latest.get("volume_ratio")
    taker_buy = latest.get("taker_buy_ratio")
    score = 50.0
    details: list[str] = []

    if pd.notna(vol_ratio):
        if vol_ratio >= 1.5:
            score += 10
            details.append(f"Volume surge ({vol_ratio:.2f}x average)")
        elif vol_ratio <= 0.7:
            score -= 8
            details.append(f"Low volume ({vol_ratio:.2f}x average)")
        else:
            details.append(f"Normal volume ({vol_ratio:.2f}x average)")

    if pd.notna(taker_buy):
        if taker_buy >= 0.55:
            score += 12
            details.append(f"Strong taker buy pressure ({taker_buy:.1%})")
        elif taker_buy <= 0.45:
            score -= 12
            details.append(f"Taker sell dominance ({taker_buy:.1%})")
        else:
            details.append(f"Balanced taker flow ({taker_buy:.1%})")

    return ComponentScore(
        name="Volume",
        score=_clamp(score),
        weight=0.15,
        detail="; ".join(details) or "Volume data neutral",
    )


def _score_heatmap(
    heatmap: pd.DataFrame | None,
    price: float,
    source: str,
) -> ComponentScore:
    if heatmap is None or heatmap.empty:
        return ComponentScore(
            name="Heatmap",
            score=50.0,
            weight=0.10,
            detail="No heatmap data available",
        )

    below = heatmap[heatmap["price_level"] < price]
    above = heatmap[heatmap["price_level"] > price]

    support_strength = below["intensity"].sum() if not below.empty else 0
    resistance_strength = above["intensity"].sum() if not above.empty else 0
    total = support_strength + resistance_strength

    score = 50.0
    if total > 0:
        support_pct = support_strength / total
        score = support_pct * 100

    nearest_support = below.iloc[-1]["price_level"] if not below.empty else None
    nearest_resistance = above.iloc[0]["price_level"] if not above.empty else None

    details = [f"Source: {source}"]
    if nearest_support is not None:
        details.append(f"Nearest support ~${nearest_support:,.0f}")
    if nearest_resistance is not None:
        details.append(f"Nearest resistance ~${nearest_resistance:,.0f}")
    if total > 0:
        details.append(f"Support vs resistance intensity: {support_strength / total:.0%} / {resistance_strength / total:.0%}")

    return ComponentScore(
        name="Heatmap",
        score=_clamp(score),
        weight=0.10,
        detail="; ".join(details),
    )


def _score_derivatives(
    funding_rate: float | None,
    long_short_ratio: float | None,
    oi_change_pct: float | None,
) -> ComponentScore:
    score = 50.0
    details: list[str] = []

    if funding_rate is not None:
        if funding_rate > 0.0005:
            score -= 10
            details.append(f"Elevated positive funding ({funding_rate:.4%}) — crowded longs")
        elif funding_rate < -0.0002:
            score += 10
            details.append(f"Negative funding ({funding_rate:.4%}) — shorts paying longs")
        else:
            details.append(f"Funding rate neutral ({funding_rate:.4%})")

    if long_short_ratio is not None:
        if long_short_ratio > 1.2:
            score -= 8
            details.append(f"Long-heavy positioning (L/S {long_short_ratio:.2f})")
        elif long_short_ratio < 0.85:
            score += 8
            details.append(f"Short-heavy positioning (L/S {long_short_ratio:.2f})")
        else:
            details.append(f"Balanced long/short ratio ({long_short_ratio:.2f})")

    if oi_change_pct is not None:
        if oi_change_pct > 3:
            details.append(f"Open interest rising (+{oi_change_pct:.1f}%) — new capital entering")
        elif oi_change_pct < -3:
            details.append(f"Open interest falling ({oi_change_pct:.1f}%) — positions unwinding")

    return ComponentScore(
        name="Derivatives Sentiment",
        score=_clamp(score),
        weight=0.15,
        detail="; ".join(details) or "Derivatives data neutral",
    )


def _recommendation_from_score(score: float) -> Recommendation:
    if score >= 62:
        return "long"
    if score <= 38:
        return "short"
    return "wait"


def _confidence_label(score: float, components: list[ComponentScore], hub: HubSnapshot | None = None) -> str:
    spread = max(c.score for c in components) - min(c.score for c in components)
    distance_from_neutral = abs(score - 50)

    if distance_from_neutral >= 25 and spread <= 35:
        base = "High"
    elif distance_from_neutral >= 15:
        base = "Medium"
    else:
        base = "Low"

    if hub is None:
        return base

    missing = len(hub.missing_fields)
    if hub.critical_missing or missing >= 4:
        return "Low"
    if missing >= 2 and base == "High":
        return "Medium"
    if missing >= 1 and base == "High":
        return "Medium"
    return base


def _calc_sl_tp(
    price: float,
    recommendation: Recommendation,
    df: pd.DataFrame,
    heatmap: pd.DataFrame | None,
) -> tuple[float, float, float]:
    atr_proxy = (df["high"] - df["low"]).tail(14).mean()
    if pd.isna(atr_proxy) or atr_proxy <= 0:
        atr_proxy = price * 0.015

    support = price - atr_proxy * 1.5
    resistance = price + atr_proxy * 1.5

    if heatmap is not None and not heatmap.empty:
        below = heatmap[heatmap["price_level"] < price]
        above = heatmap[heatmap["price_level"] > price]
        if not below.empty:
            support = below.loc[below["intensity"].idxmax(), "price_level"]
        if not above.empty:
            resistance = above.loc[above["intensity"].idxmax(), "price_level"]

    if recommendation == "long":
        stop_loss = min(support, price - atr_proxy)
        take_profit = max(resistance, price + atr_proxy * 2)
    elif recommendation == "short":
        stop_loss = max(resistance, price + atr_proxy)
        take_profit = min(support, price - atr_proxy * 2)
    else:
        stop_loss = price - atr_proxy
        take_profit = price + atr_proxy

    risk = abs(price - stop_loss)
    reward = abs(take_profit - price)
    rr = reward / risk if risk > 0 else 0.0
    return stop_loss, take_profit, rr


def _build_explanation(
    result_score: float,
    recommendation: Recommendation,
    confidence: str,
    components: list[ComponentScore],
    price: float,
    stop_loss: float,
    take_profit: float,
    data_sources: list[str],
    heatmap_source: str,
    hub: HubSnapshot | None = None,
) -> str:
    rec_text = {
        "long": "enter a long position",
        "short": "enter a short position",
        "wait": "stay on the sidelines and wait for clearer confirmation",
    }[recommendation]

    lines = [
        f"Bitcoin is trading at ${price:,.2f}. The composite score is {result_score:.1f}/100, "
        f"suggesting you should {rec_text}. Confidence is {confidence.lower()}.",
        "",
        "Signal breakdown:",
    ]

    for component in components:
        bias = "bullish" if component.score >= 55 else "bearish" if component.score <= 45 else "neutral"
        lines.append(
            f"• {component.name} ({component.score:.0f}/100, {bias}): {component.detail}"
        )

    lines.extend(
        [
            "",
            f"Risk management: stop loss at ${stop_loss:,.2f}, take profit at ${take_profit:,.2f}.",
            f"Heatmap derived from {heatmap_source}.",
            f"Data sources used in signal: {', '.join(data_sources)}.",
        ]
    )

    if hub is not None:
        lines.extend(
            [
                "",
                "Data Hub summary:",
                f"• Quality: {hub.data_quality} ({hub.confidence_impact})",
                f"• Available: {', '.join(hub.available_fields) or 'none'}",
            ]
        )
        if hub.missing_fields:
            lines.append(f"• Missing: {', '.join(hub.missing_fields)}")
        if hub.force_wait:
            lines.append("• Critical market data missing — WAIT enforced by Data Hub.")
        online = [name for name, info in hub.source_status.items() if info.status == "online"]
        if online:
            lines.append(f"• Online sources: {', '.join(online)}")

    lines.extend(
        [
            "",
            "Note: This is a technical analysis tool, not financial advice. "
            "Always validate signals with your own research and position sizing rules.",
        ]
    )
    return "\n".join(lines)


class MarketAnalyzer:
    def __init__(
        self,
        symbol: str = "BTCUSDT",
        interval: str = "1h",
        coinglass_api_key: str | None = None,
    ) -> None:
        self.symbol = symbol
        self.interval = interval
        self.data_hub = BitcoinDataHub(symbol=symbol, coinglass_api_key=coinglass_api_key)

    def analyze(self) -> AnalysisResult:
        hub = self.data_hub.fetch(interval=self.interval, limit=500)

        if hub.force_wait or hub.price is None or hub.candles is None or hub.candles.empty:
            return self._missing_data_result(hub)

        df = compute_emas(hub.candles)
        df = compute_macd(df)
        df = compute_rsi(df)
        df = compute_volume_metrics(df)

        price = float(hub.price)
        funding = hub.funding_rate
        long_short = hub.long_short_ratio
        oi_change_pct = hub.open_interest_change_pct

        data_sources = list(hub.sources) or ["Binance"]
        heatmap_source = "volume profile (Binance)"
        heatmap = build_volume_heatmap(df)

        if self.data_hub.coinglass.enabled:
            try:
                cg_heatmap = self.data_hub.coinglass.get_liquidation_heatmap()
                parsed = parse_coinglass_heatmap(cg_heatmap, price)
                if parsed is not None and not parsed.empty:
                    heatmap = parsed
                    heatmap_source = "Coinglass liquidation heatmap"
            except Exception:
                pass

        components = [
            _score_ema_trend(df),
            _score_macd(df),
            _score_rsi(df),
            _score_volume(df),
            _score_heatmap(heatmap, price, heatmap_source),
            _score_derivatives(funding, long_short, oi_change_pct),
        ]

        total_weight = sum(c.weight for c in components)
        score = sum(c.score * c.weight for c in components) / total_weight
        score = _clamp(score)

        recommendation = _recommendation_from_score(score)
        if hub.force_wait:
            recommendation = "wait"

        confidence = _confidence_label(score, components, hub)
        stop_loss, take_profit, rr = _calc_sl_tp(price, recommendation, df, heatmap)

        latest = df.iloc[-1]
        indicators = {
            "ema_9": float(latest.get("ema_9", 0) or 0),
            "ema_21": float(latest.get("ema_21", 0) or 0),
            "ema_50": float(latest.get("ema_50", 0) or 0),
            "ema_200": float(latest.get("ema_200", 0) or 0),
            "macd": float(latest.get("macd", 0) or 0),
            "macd_signal": float(latest.get("macd_signal", 0) or 0),
            "macd_hist": float(latest.get("macd_hist", 0) or 0),
            "rsi": float(latest.get("rsi", 0) or 0),
            "volume_ratio": float(latest.get("volume_ratio", 0) or 0),
            "taker_buy_ratio": float(latest.get("taker_buy_ratio", 0) or 0),
            "funding_rate": funding,
            "long_short_ratio": long_short,
            "oi_change_pct": oi_change_pct,
        }

        explanation = _build_explanation(
            score,
            recommendation,
            confidence,
            components,
            price,
            stop_loss,
            take_profit,
            data_sources,
            heatmap_source,
            hub,
        )

        result = AnalysisResult(
            symbol=self.symbol,
            price=price,
            score=score,
            recommendation=recommendation,
            confidence=confidence,
            stop_loss=stop_loss,
            take_profit=take_profit,
            risk_reward=rr,
            explanation=explanation,
            components=components,
            indicators=indicators,
            heatmap_source=heatmap_source,
            data_sources=data_sources,
            heatmap=heatmap,
            hub=hub.to_dict(),
            supported_sources=data_sources,
            data_quality=hub.data_quality,
        )

        try:
            from src.analysis.ai_decision_engine import enrich_analysis

            return enrich_analysis(
                result,
                candles=df,
                heatmap=heatmap,
                coinglass_enabled=self.data_hub.coinglass.enabled,
            )
        except Exception:
            return result

    def _missing_data_result(self, hub: HubSnapshot) -> AnalysisResult:
        price = float(hub.price or 0)
        missing_text = ", ".join(hub.missing_fields) or "critical market feeds"
        explanation = (
            f"Unable to produce a directional signal because required data is missing ({missing_text}).\n\n"
            f"Data Hub quality: {hub.data_quality}. Confidence impact: {hub.confidence_impact}.\n"
            f"Connected sources: {', '.join(hub.sources) or 'none'}.\n\n"
            "Recommendation: WAIT until price and candle data are available.\n\n"
            "Note: This is a technical analysis tool, not financial advice."
        )
        return AnalysisResult(
            symbol=self.symbol,
            price=price,
            score=50.0,
            recommendation="wait",
            confidence="Low",
            stop_loss=price * 0.985 if price else 0.0,
            take_profit=price * 1.015 if price else 0.0,
            risk_reward=0.0,
            explanation=explanation,
            components=[
                ComponentScore(
                    name="Data Hub",
                    score=50.0,
                    weight=1.0,
                    detail=f"Missing required fields: {missing_text}",
                )
            ],
            indicators={},
            heatmap_source="unavailable",
            data_sources=list(hub.sources),
            heatmap=None,
            hub=hub.to_dict(),
            supported_sources=list(hub.sources),
            data_quality=hub.data_quality,
        )
```

---

<a id="file-src-analysis-sentiment-py"></a>
## File: `src/analysis/sentiment.py`

```python
"""Simple keyword-based headline sentiment analysis."""

from __future__ import annotations

from typing import Any

POSITIVE_WORDS = frozenset(
    {
        "bullish",
        "etf",
        "inflow",
        "rally",
        "breakout",
        "adoption",
        "institutional",
        "surge",
        "record",
        "approval",
        "accumulation",
    }
)

NEGATIVE_WORDS = frozenset(
    {
        "bearish",
        "hack",
        "lawsuit",
        "outflow",
        "crash",
        "liquidation",
        "ban",
        "selloff",
        "fraud",
        "exploit",
        "collapse",
        "dump",
    }
)


def analyze_headline_sentiment(text: str) -> str:
    """Return positive, negative, or neutral for a headline."""
    tokens = {word.strip(".,!?\"'()[]") for word in text.lower().split()}
    pos = len(tokens & POSITIVE_WORDS)
    neg = len(tokens & NEGATIVE_WORDS)
    if pos > neg:
        return "positive"
    if neg > pos:
        return "negative"
    return "neutral"


def summarize_sentiment(headlines: list[dict[str, Any]]) -> dict[str, Any]:
    if not headlines:
        return {
            "label": "neutral",
            "positive": 0,
            "negative": 0,
            "neutral": 0,
            "score": 50,
        }

    counts = {"positive": 0, "negative": 0, "neutral": 0}
    for item in headlines:
        label = str(item.get("sentiment", "neutral"))
        counts[label] = counts.get(label, 0) + 1

    total = max(len(headlines), 1)
    score = 50 + int(((counts["positive"] - counts["negative"]) / total) * 50)
    score = max(0, min(100, score))

    if counts["positive"] > counts["negative"]:
        label = "bullish"
    elif counts["negative"] > counts["positive"]:
        label = "bearish"
    else:
        label = "neutral"

    return {
        "label": label,
        "positive": counts["positive"],
        "negative": counts["negative"],
        "neutral": counts["neutral"],
        "score": score,
    }
```

---

<a id="file-src-analysis-risk_manager-py"></a>
## File: `src/analysis/risk_manager.py`

```python
"""Risk management: levels, position sizing, take-profit targets."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from src.analysis.models import AnalysisResult, Recommendation
from src.ui.theme import confidence_percent


@dataclass
class TakeProfitLevels:
    tp1: float
    tp2: float
    tp3: float
    tp4: float


@dataclass
class RiskProfile:
    level: str
    probability: float
    invalidation: float
    position_size_btc: float
    position_size_usd: float
    risk_per_trade_usd: float


def _atr(df: pd.DataFrame, price: float) -> float:
    atr_proxy = (df["high"] - df["low"]).tail(14).mean()
    if pd.isna(atr_proxy) or atr_proxy <= 0:
        atr_proxy = price * 0.015
    return float(atr_proxy)


def compute_take_profits(
    price: float,
    recommendation: Recommendation,
    df: pd.DataFrame,
) -> TakeProfitLevels:
    atr = _atr(df, price)
    if recommendation == "short":
        return TakeProfitLevels(
            tp1=price - atr * 0.75,
            tp2=price - atr * 1.5,
            tp3=price - atr * 2.5,
            tp4=price - atr * 4.0,
        )
    if recommendation == "long":
        return TakeProfitLevels(
            tp1=price + atr * 0.75,
            tp2=price + atr * 1.5,
            tp3=price + atr * 2.5,
            tp4=price + atr * 4.0,
        )
    return TakeProfitLevels(
        tp1=price + atr * 0.5,
        tp2=price + atr * 1.0,
        tp3=price + atr * 1.5,
        tp4=price + atr * 2.0,
    )


def compute_invalidation(price: float, recommendation: Recommendation, stop_loss: float) -> float:
    if recommendation == "long":
        return min(stop_loss, price * 0.985)
    if recommendation == "short":
        return max(stop_loss, price * 1.015)
    return stop_loss


def compute_risk_profile(
    result: AnalysisResult,
    df: pd.DataFrame,
    *,
    account_size: float = 10_000.0,
    risk_pct: float = 1.0,
) -> RiskProfile:
    risk_per_unit = abs(result.price - result.stop_loss)
    risk_budget = account_size * (risk_pct / 100.0)
    position_btc = risk_budget / risk_per_unit if risk_per_unit > 0 else 0.0
    position_usd = position_btc * result.price

    conf_pct = confidence_percent(result.confidence)
    atr = _atr(df, result.price)
    volatility_pct = (atr / result.price) * 100 if result.price else 0.0

    probability = min(0.85, max(0.25, (conf_pct / 100.0) * 0.55 + (abs(result.score - 50) / 50.0) * 0.35))

    if conf_pct >= 70 and volatility_pct < 2.5:
        level = "LOW"
    elif conf_pct >= 50 and volatility_pct < 4.0:
        level = "MEDIUM"
    else:
        level = "HIGH"

    if result.recommendation == "wait":
        level = "HIGH"
        probability = min(probability, 0.35)

    invalidation = compute_invalidation(result.price, result.recommendation, result.stop_loss)

    return RiskProfile(
        level=level,
        probability=round(probability, 2),
        invalidation=invalidation,
        position_size_btc=round(position_btc, 6),
        position_size_usd=round(position_usd, 2),
        risk_per_trade_usd=round(risk_budget, 2),
    )
```

---

<a id="file-src-analysis-ai_decision_engine-py"></a>
## File: `src/analysis/ai_decision_engine.py`

```python
"""AI decision engine — enriches MarketAnalyzer output with dashboard insights."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

import pandas as pd

from src.analysis.models import AnalysisResult, DashboardInsights, MarketStatusPanel, TradeQuality
from src.analysis.risk_manager import (
    TakeProfitLevels,
    compute_risk_profile,
    compute_take_profits,
)
from src.data.fear_greed import FearGreedClient
from src.data.news_client import NewsClient
from src.data.onchain_client import OnChainClient
from src.data.whale_client import WhaleClient
from src.ui.theme import confidence_percent


def enrich_analysis(
    result: AnalysisResult,
    *,
    candles: pd.DataFrame,
    heatmap: pd.DataFrame | None = None,
    account_size: float = 10_000.0,
    risk_pct: float = 1.0,
    coinglass_enabled: bool = False,
) -> AnalysisResult:
    """Attach dashboard insights without changing core recommendation logic."""
    try:
        fear_data, fear_info = FearGreedClient().fetch()
        news_data, news_info = NewsClient().fetch()
        onchain_data, onchain_info = OnChainClient().fetch()
        whale_data, whale_info = WhaleClient().fetch()
    except Exception as exc:
        result.enhanced_explanation = result.explanation
        result.insights = None
        return result

    market_status = _market_status(result, candles)
    trade_quality = _trade_quality(result)
    take_profits = compute_take_profits(result.price, result.recommendation, candles)
    risk_profile = compute_risk_profile(
        result,
        candles,
        account_size=account_size,
        risk_pct=risk_pct,
    )
    reasons_enter, reasons_avoid = _entry_reasons(result, candles, heatmap)

    source_status = _build_source_status(
        result,
        fear_info=fear_info,
        news_info=news_info,
        onchain_info=onchain_info,
        whale_info=whale_info,
        coinglass_enabled=coinglass_enabled,
    )

    enhanced = _build_enhanced_explanation(
        result=result,
        market_status=market_status,
        trade_quality=trade_quality,
        take_profits=take_profits,
        risk_profile=risk_profile,
        reasons_enter=reasons_enter,
        reasons_avoid=reasons_avoid,
        fear_data=fear_data,
        news_data=news_data,
    )

    result.take_profits = asdict(take_profits)
    result.risk_profile = asdict(risk_profile)
    result.reasons_enter = reasons_enter
    result.reasons_avoid = reasons_avoid
    result.fear_greed = fear_data
    result.news_sentiment = news_data
    result.onchain_data = onchain_data
    result.whale_data = whale_data
    result.source_status = source_status
    result.enhanced_explanation = enhanced
    result.insights = DashboardInsights(
        market_status=market_status,
        trade_quality=trade_quality,
        fear_greed=fear_data,
        news_sentiment=news_data,
        onchain_data=onchain_data,
        whale_data=whale_data,
        source_status=source_status,
    )
    return result


def _market_status(result: AnalysisResult, df: pd.DataFrame) -> MarketStatusPanel:
    atr = (df["high"] - df["low"]).tail(14).mean()
    vol_pct = (atr / result.price) * 100 if result.price else 0.0
    volume_ratio = float(result.indicators.get("volume_ratio") or 1.0)

    if result.score >= 58:
        trend = "Bullish"
    elif result.score <= 42:
        trend = "Bearish"
    else:
        trend = "Sideways"

    volatility = "High volatility" if vol_pct >= 2.5 else "Normal volatility"
    liquidity = "Low liquidity" if volume_ratio < 0.8 else "Normal liquidity"

    return MarketStatusPanel(
        trend=trend,
        volatility=volatility,
        liquidity=liquidity,
    )


def _trade_quality(result: AnalysisResult) -> TradeQuality:
    conf_pct = confidence_percent(result.confidence)
    composite = (result.score * 0.45) + (conf_pct * 0.55)

    if result.recommendation == "wait" or conf_pct < 40:
        grade = "No Trade"
        stars = 0
    elif composite >= 82:
        grade = "A+"
        stars = 5
    elif composite >= 72:
        grade = "A"
        stars = 4
    elif composite >= 60:
        grade = "B"
        stars = 3
    else:
        grade = "C"
        stars = 2

    return TradeQuality(
        grade=grade,
        score=int(round(composite)),
        stars=stars,
    )


def _entry_reasons(
    result: AnalysisResult,
    df: pd.DataFrame,
    heatmap: pd.DataFrame | None,
) -> tuple[list[str], list[str]]:
    ind = result.indicators
    latest = df.iloc[-1]
    enter: list[str] = []
    avoid: list[str] = []

    ema9 = latest.get("ema_9")
    ema21 = latest.get("ema_21")
    ema50 = latest.get("ema_50")
    ema200 = latest.get("ema_200")
    if pd.notna(ema9) and pd.notna(ema21) and pd.notna(ema50) and pd.notna(ema200):
        if ema9 > ema21 > ema50 > ema200:
            enter.append("EMA alignment — bullish stack")
        elif ema9 < ema21 < ema50 < ema200:
            enter.append("EMA alignment — bearish stack")
        else:
            avoid.append("Mixed EMA alignment")

    rsi = ind.get("rsi")
    if rsi is not None:
        if 45 <= rsi <= 65:
            enter.append(f"RSI condition healthy ({rsi:.1f})")
        elif rsi >= 75:
            avoid.append(f"RSI overbought ({rsi:.1f})")
        elif rsi <= 25:
            avoid.append(f"RSI oversold ({rsi:.1f}) — reversal risk")

    macd_hist = ind.get("macd_hist")
    if macd_hist is not None:
        if macd_hist > 0:
            enter.append("MACD direction — bullish momentum")
        elif macd_hist < 0:
            enter.append("MACD direction — bearish momentum")

    volume_ratio = ind.get("volume_ratio") or 0
    if volume_ratio >= 1.1:
        enter.append(f"Volume confirmation ({volume_ratio:.2f}x average)")
    elif volume_ratio < 0.8:
        avoid.append(f"Weak volume ({volume_ratio:.2f}x average)")

    funding = ind.get("funding_rate")
    if funding is not None:
        if abs(funding) <= 0.0003:
            enter.append("Funding neutral")
        elif abs(funding) >= 0.0008:
            avoid.append(f"High funding ({funding:.4%})")

    ls_ratio = ind.get("long_short_ratio")
    if ls_ratio is not None:
        enter.append(f"Long/Short ratio at {ls_ratio:.2f}")

    if heatmap is not None and not heatmap.empty:
        below = heatmap[heatmap["price_level"] < result.price]
        above = heatmap[heatmap["price_level"] > result.price]
        if not below.empty:
            enter.append("Heatmap support nearby")
        if not above.empty:
            support_res = "Heatmap resistance nearby"
            if result.recommendation == "long":
                avoid.append(support_res)
            else:
                enter.append(support_res)

    spread = max(c.score for c in result.components) - min(c.score for c in result.components) if result.components else 0
    if spread <= 25:
        enter.append("Trend strength — indicators aligned")
    else:
        avoid.append("Mixed indicators — low alignment")

    conf_pct = confidence_percent(result.confidence)
    if conf_pct < 70:
        avoid.append(f"Low confidence ({conf_pct}%)")

    atr = (df["high"] - df["low"]).tail(14).mean()
    if result.price and (atr / result.price) * 100 >= 3.0:
        avoid.append("Too much volatility for aggressive entries")

    if not enter:
        enter.append("No strong entry confirmations detected")
    if not avoid:
        avoid.append("No major warning flags detected")

    return enter, avoid


def _build_source_status(
    result: AnalysisResult,
    *,
    fear_info,
    news_info,
    onchain_info,
    whale_info,
    coinglass_enabled: bool,
) -> dict[str, Any]:
    hub_sources = (result.hub or {}).get("source_status") or {}
    binance_status = "online" if "Binance" in (result.data_sources or []) else hub_sources.get("Binance", {}).get("status", "offline")

    return {
        "Binance": binance_status,
        "Coinglass": "online" if coinglass_enabled else hub_sources.get("Coinglass", {}).get("status", "offline"),
        "Fear & Greed": fear_info.status,
        "News RSS": news_info.status,
        "On-chain": onchain_info.status,
        "Whale data": whale_info.status,
    }


def _build_enhanced_explanation(
    *,
    result: AnalysisResult,
    market_status: MarketStatusPanel,
    trade_quality: TradeQuality,
    take_profits: TakeProfitLevels,
    risk_profile,
    reasons_enter: list[str],
    reasons_avoid: list[str],
    fear_data: dict,
    news_data: dict,
) -> str:
    conf_pct = confidence_percent(result.confidence)
    lines = [
        "=== Ofir Kadosh Bitcoin AI Dashboard — Analysis Report ===",
        "",
        f"Recommendation: {result.recommendation.upper()}",
        f"Why: Composite score {result.score:.1f}/100 with {result.confidence} confidence ({conf_pct}%).",
        "",
        "What confirms the setup:",
    ]
    lines.extend([f"  ✓ {item}" for item in reasons_enter[:8]])
    lines.extend(["", "What can cancel the setup:"])
    lines.extend([f"  ✗ {item}" for item in reasons_avoid[:8]])
    lines.extend(
        [
            "",
            f"Suggested stop loss: ${result.stop_loss:,.2f}",
            f"Invalidation level: ${risk_profile.invalidation:,.2f}",
            f"TP targets: TP1 ${take_profits.tp1:,.2f} | TP2 ${take_profits.tp2:,.2f} | "
            f"TP3 ${take_profits.tp3:,.2f} | TP4 ${take_profits.tp4:,.2f}",
            "",
            f"Risk level: {risk_profile.level} | Estimated probability: {risk_profile.probability:.0%}",
            f"Position size (1% risk): {risk_profile.position_size_btc:.6f} BTC "
            f"(${risk_profile.position_size_usd:,.2f})",
            "",
            f"Market status: {market_status.trend} | {market_status.volatility} | {market_status.liquidity}",
            f"Trade quality: {trade_quality.grade} ({trade_quality.score}/100)",
            "",
        ]
    )

    if fear_data.get("value") is not None:
        lines.append(
            f"Fear & Greed Index: {fear_data['value']} ({fear_data.get('classification', 'N/A')})"
        )
    news_summary = news_data.get("summary") or {}
    if news_summary:
        lines.append(
            f"News sentiment: {news_summary.get('label', 'neutral')} "
            f"(score {news_summary.get('score', 50)}/100)"
        )

    lines.extend(
        [
            "",
            "Disclaimer: Educational tool only. Not financial advice. "
            "Past performance does not guarantee future results.",
        ]
    )
    return "\n".join(lines)
```

---

<a id="file-src-ui-__init__-py"></a>
## File: `src/ui/__init__.py`

```python
"""UI layer public exports."""

from src.ui.components import (
    render_analyze_button,
    render_dashboard,
    render_empty_state,
    render_error_state,
    render_header_bar,
)
from src.ui.sidebar import SidebarSettings, render_sidebar
from src.ui.styles import inject_global_styles

__all__ = [
    "SidebarSettings",
    "inject_global_styles",
    "render_sidebar",
    "render_header_bar",
    "render_analyze_button",
    "render_empty_state",
    "render_error_state",
    "render_dashboard",
]
```

---

<a id="file-src-ui-theme-py"></a>
## File: `src/ui/theme.py`

```python
"""Design tokens and theme palettes."""

from __future__ import annotations

APP_VERSION = "1.0"

BRAND = {
    "author_he": "אופיר קדוש",
    "author_en": "Ofir Kadosh",
    "since_year": "2026",
    "product": "Ofir Kadosh Bitcoin AI Dashboard",
    "website": "http://kadoshofirk.com",
    "website_label": "kadoshofirk.com",
}


def brand_caption() -> str:
    """Author line shown under the app title."""
    return f"{BRAND['author_en'].lower()} {APP_VERSION} Since {BRAND['since_year']} Project"


# Bitcoin brand colors
BITCOIN_ORANGE = "#F7931A"
BITCOIN_ORANGE_DARK = "#E8820C"
BITCOIN_ORANGE_LIGHT = "#FFB84D"
BITCOIN_GOLD = "#F2A900"
BITCOIN_CREAM = "#FFF4E6"
BITCOIN_CREAM_SURFACE = "#FFFAF3"

LIGHT_PALETTE = {
    "bg": "#FFF4E6",
    "surface": "#FFFAF3",
    "surface_alt": "#FFEED9",
    "border": "#F5D5A8",
    "text": "#1A1108",
    "text_secondary": "#6B4423",
    "text_muted": "#9A7349",
    "accent": BITCOIN_ORANGE,
    "accent_hover": BITCOIN_ORANGE_DARK,
    "accent_soft": "#FFE8CC",
    "long": "#059669",
    "long_bg": "#ecfdf5",
    "long_border": "#a7f3d0",
    "short": "#dc2626",
    "short_bg": "#fef2f2",
    "short_border": "#fecaca",
    "wait": BITCOIN_GOLD,
    "wait_bg": "#FFF8E7",
    "wait_border": "#F5D58A",
    "error_bg": "#fef2f2",
    "error_border": "#fecaca",
    "error_text": "#991b1b",
    "heatmap_mid": BITCOIN_GOLD,
    "chart_grid": "#F5D5A8",
}

DARK_PALETTE = {
    "bg": "#1A1108",
    "surface": "#2A1A0E",
    "surface_alt": "#3D2614",
    "border": "#5C3D1E",
    "text": "#FFF4E6",
    "text_secondary": "#D4A574",
    "text_muted": "#9A7349",
    "accent": BITCOIN_ORANGE,
    "accent_hover": BITCOIN_ORANGE_LIGHT,
    "accent_soft": "rgba(247, 147, 26, 0.18)",
    "long": "#34d399",
    "long_bg": "#064e3b",
    "long_border": "#065f46",
    "short": "#f87171",
    "short_bg": "#450a0a",
    "short_border": "#7f1d1d",
    "wait": BITCOIN_GOLD,
    "wait_bg": "#3D2E0A",
    "wait_border": "#78550F",
    "error_bg": "#450a0a",
    "error_border": "#7f1d1d",
    "error_text": "#fecaca",
    "heatmap_mid": BITCOIN_ORANGE,
    "chart_grid": "#5C3D1E",
}

SPACING = {"xs": "0.5rem", "sm": "0.75rem", "md": "1rem", "lg": "1.5rem", "xl": "2rem"}
RADIUS = {"sm": "10px", "md": "14px", "full": "999px"}
SHADOW = {
    "sm": "0 1px 3px rgba(15, 23, 42, 0.08), 0 1px 2px rgba(15, 23, 42, 0.04)",
    "md": "0 8px 24px rgba(15, 23, 42, 0.1)",
}

RECOMMENDATION_STYLE: dict[str, dict[str, str]] = {
    "long": {"label": "LONG", "symbol": "▲", "tone": "long"},
    "short": {"label": "SHORT", "symbol": "▼", "tone": "short"},
    "wait": {"label": "WAIT", "symbol": "◆", "tone": "wait"},
}

PLOTLY_CONFIG = {"displayModeBar": False, "responsive": True}


def get_palette(dark: bool = False) -> dict[str, str]:
    return DARK_PALETTE if dark else LIGHT_PALETTE


def score_tone(score: float) -> str:
    if score >= 62:
        return "long"
    if score <= 38:
        return "short"
    return "wait"


def score_color(score: float, dark: bool = False) -> str:
    palette = get_palette(dark)
    return palette[score_tone(score)]


def gauge_steps(dark: bool = False) -> list[dict]:
    palette = get_palette(dark)
    return [
        {"range": [0, 38], "color": palette["short_bg"]},
        {"range": [38, 62], "color": palette["wait_bg"]},
        {"range": [62, 100], "color": palette["long_bg"]},
    ]


def confidence_percent(confidence: str) -> int:
    return {"High": 85, "Medium": 62, "Low": 38}.get(confidence, 50)


def chart_layout(palette: dict[str, str]) -> dict:
    return {
        "paper_bgcolor": "rgba(0,0,0,0)",
        "plot_bgcolor": "rgba(0,0,0,0)",
        "font": {
            "family": "Inter, system-ui, sans-serif",
            "color": palette["text_secondary"],
            "size": 12,
        },
        "margin": {"l": 12, "r": 12, "t": 44, "b": 12},
        "xaxis": {"gridcolor": palette["chart_grid"], "zerolinecolor": palette["chart_grid"]},
        "yaxis": {"gridcolor": palette["chart_grid"], "zerolinecolor": palette["chart_grid"]},
    }
```

---

<a id="file-src-ui-time_utils-py"></a>
## File: `src/ui/time_utils.py`

```python
"""Datetime helpers for session state and UI display."""

from __future__ import annotations

from datetime import datetime


def normalize_last_updated(value: object) -> datetime | None:
    """Return a datetime from session state, or None if missing or invalid."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    return None


def format_last_updated(value: object) -> str:
    """Format timestamp for display; safe when value is None or invalid."""
    dt = normalize_last_updated(value)
    if dt is None:
        return "Not updated yet"
    return dt.strftime("%b %d, %Y · %H:%M UTC")
```

---

<a id="file-src-ui-helpers-py"></a>
## File: `src/ui/helpers.py`

```python
"""UI helper utilities — presentation text and safe formatting."""

from __future__ import annotations

from typing import TYPE_CHECKING

from src.ui.time_utils import format_last_updated, normalize_last_updated

if TYPE_CHECKING:
    from src.analysis.models import AnalysisResult

from src.ui.theme import confidence_percent

__all__ = [
    "normalize_last_updated",
    "format_last_updated",
    "component_bias",
    "recommendation_insight",
    "signal_plain_language_summary",
    "indicator_rows",
]


def component_bias(score: float) -> str:
    if score >= 55:
        return "bullish"
    if score <= 45:
        return "bearish"
    return "neutral"


def recommendation_insight(result: AnalysisResult) -> str:
    """One-line assistant-style summary for the recommendation panel."""
    drivers = sorted(result.components, key=lambda c: abs(c.score - 50), reverse=True)[:2]
    driver_text = ", ".join(f"{c.name} ({component_bias(c.score)})" for c in drivers)

    templates = {
        "long": (
            f"Bullish momentum detected across key indicators. "
            f"Primary drivers: {driver_text}. Consider long exposure with defined risk."
        ),
        "short": (
            f"Bearish pressure is building in the market structure. "
            f"Primary drivers: {driver_text}. Short bias favored with tight risk control."
        ),
        "wait": (
            f"Signals are mixed and conviction is low. "
            f"Primary drivers: {driver_text}. Wait for clearer alignment before entering."
        ),
    }
    return templates[result.recommendation]


def signal_plain_language_summary(
    recommendation: str,
    confidence: str,
    score: float,
) -> list[tuple[str, str]]:
    """Plain-language explanation of direction, confidence, and suggested action."""
    pct = confidence_percent(confidence)
    direction_label = recommendation.upper()

    direction_text = {
        "long": (
            f"The overall score is {score:.0f}/100. "
            "Technically, the market leans bullish — a buy-side bias (LONG)."
        ),
        "short": (
            f"The overall score is {score:.0f}/100. "
            "Technically, the market leans bearish — a sell-side bias (SHORT)."
        ),
        "wait": (
            f"The overall score is {score:.0f}/100. "
            "Signals are mixed — there is no clear direction yet (WAIT)."
        ),
    }[recommendation]

    confidence_text = {
        "High": (
            f"Confidence is high ({pct}%). "
            "Most indicators point the same way — the signal is relatively strong."
        ),
        "Medium": (
            f"Confidence is medium ({pct}%). "
            "Some indicators agree, but not all — proceed with caution."
        ),
        "Low": (
            f"Confidence is low ({pct}%). "
            "Indicators disagree or some data is missing — the signal is weak."
        ),
    }.get(
        confidence,
        f"Confidence is {confidence.lower()} ({pct}%).",
    )

    if recommendation == "wait":
        action_text = "Stay on the sidelines until indicators align more clearly."
    elif pct >= 70:
        action_text = (
            f"Direction and confidence agree. "
            f"You may consider a {direction_label} setup with defined risk and a stop loss."
        )
    else:
        action_text = (
            f"The badge shows {direction_label}, but confidence is too low for an aggressive entry. "
            "Wait for stronger alignment before opening a position."
        )

    return [
        ("Direction", direction_text),
        ("Confidence", confidence_text),
        ("What to do", action_text),
    ]


def indicator_rows(result: AnalysisResult) -> list[tuple[str, str, str | None]]:
    """Return (label, value, tone) tuples for indicator metric cards."""
    ind = result.indicators
    rows: list[tuple[str, str, str | None]] = [
        ("RSI (14)", f"{ind.get('rsi', 0):.1f}", _rsi_tone(ind.get("rsi"))),
        ("MACD Histogram", f"{ind.get('macd_hist', 0):.2f}", _macd_tone(ind.get("macd_hist"))),
        ("EMA 9", f"${ind.get('ema_9', 0):,.2f}", None),
        ("EMA 21", f"${ind.get('ema_21', 0):,.2f}", None),
        ("EMA 50", f"${ind.get('ema_50', 0):,.2f}", None),
        ("EMA 200", f"${ind.get('ema_200', 0):,.2f}", None),
        ("Volume Ratio", f"{ind.get('volume_ratio', 0):.2f}x", None),
        ("Taker Buy %", f"{ind.get('taker_buy_ratio', 0):.1%}", None),
    ]
    if ind.get("funding_rate") is not None:
        rows.append(("Funding Rate", f"{ind['funding_rate']:.4%}", _funding_tone(ind["funding_rate"])))
    if ind.get("long_short_ratio") is not None:
        rows.append(("Long / Short Ratio", f"{ind['long_short_ratio']:.2f}", None))
    if ind.get("oi_change_pct") is not None:
        rows.append(("OI Change", f"{ind['oi_change_pct']:+.1f}%", None))
    return rows


def _rsi_tone(rsi: float | None) -> str | None:
    if rsi is None:
        return None
    if rsi >= 70:
        return "short"
    if rsi <= 30:
        return "long"
    return "wait"


def _macd_tone(hist: float | None) -> str | None:
    if hist is None:
        return None
    return "long" if hist > 0 else "short" if hist < 0 else "wait"


def _funding_tone(rate: float) -> str | None:
    if rate > 0.0005:
        return "short"
    if rate < -0.0002:
        return "long"
    return "wait"
```

---

<a id="file-src-ui-primitives-py"></a>
## File: `src/ui/primitives.py`

```python
"""HTML primitives for the dashboard UI."""

from __future__ import annotations

import html
from datetime import datetime

from src.ui.time_utils import format_last_updated, normalize_last_updated
from src.ui.theme import APP_VERSION, BRAND, RECOMMENDATION_STYLE, brand_caption, confidence_percent, score_tone


def premium_nav(*, last_updated: datetime | None = None) -> str:
    """Sticky premium SaaS navigation header."""
    title = html.escape(BRAND["product"])
    tagline = html.escape(brand_caption())

    dt = normalize_last_updated(last_updated)
    updated_text = html.escape(format_last_updated(dt))
    if dt is not None:
        status_label = "Live"
        status_class = "status-dot--live"
    else:
        status_label = "Ready"
        status_class = "status-dot--idle"

    return f"""
    <header class="premium-nav-outer">
        <div class="premium-nav">
            <div class="premium-nav__inner">
                <div class="premium-nav__left">
                    <div class="premium-nav__logo" aria-label="Bitcoin">
                        <span class="premium-nav__logo-symbol">₿</span>
                        <span class="premium-nav__logo-text">Bitcoin</span>
                    </div>
                    <div class="premium-nav__brand">
                        <h1 class="premium-nav__title">{title}</h1>
                        <p class="premium-nav__tagline">{tagline}</p>
                    </div>
                </div>
                <div class="premium-nav__right">
                    <div class="premium-nav__status">
                        <span class="status-dot {status_class}" aria-hidden="true"></span>
                        <span>{status_label}</span>
                    </div>
                    <div class="premium-nav__updated">
                        <span class="premium-nav__updated-label">Updated</span>
                        {updated_text}
                    </div>
                </div>
            </div>
            <div class="premium-nav__divider" aria-hidden="true"></div>
        </div>
    </header>
    """


def section_heading(text: str) -> str:
    return f'<h3 class="section-heading">{html.escape(text)}</h3>'


def metric_card(label: str, value: str, *, tone: str | None = None) -> str:
    tone_cls = f" card--tone-{tone}" if tone else ""
    return f"""
    <div class="card card--metric card--elevated{tone_cls}">
        <div class="card__label">{html.escape(label)}</div>
        <div class="card__value">{html.escape(value)}</div>
    </div>
    """


def metric_card_wrap(inner: str) -> str:
    return f'<div class="card-wrap">{inner}</div>'


def component_card(name: str, score: float, detail: str) -> str:
    tone = score_tone(score)
    return f"""
    <div class="card card--component card--elevated card--tone-{tone}">
        <div class="card__label">{html.escape(name)}</div>
        <div class="card__value">{score:.0f}<span class="card__suffix">/100</span></div>
        <div class="progress-track">
            <div class="progress-fill progress-fill--{tone}" style="width:{score:.0f}%;"></div>
        </div>
        <p class="card__detail">{html.escape(detail)}</p>
    </div>
    """


def recommendation_panel(
    recommendation: str,
    insight: str,
    confidence: str,
    score: float,
    *,
    summary_rows: list[tuple[str, str]] | None = None,
    show_meaning: bool = True,
    show_insight: bool = True,
) -> str:
    style = RECOMMENDATION_STYLE[recommendation]
    pct = confidence_percent(confidence)

    meaning_html = ""
    if show_meaning:
        if summary_rows is None:
            from src.ui.helpers import signal_plain_language_summary

            summary_rows = signal_plain_language_summary(recommendation, confidence, score)

        summary_html = "".join(
            f"""
            <div class="signal-summary__row">
                <div class="signal-summary__label">{html.escape(label)}</div>
                <p class="signal-summary__text">{html.escape(text)}</p>
            </div>
            """
            for label, text in summary_rows
        )
        meaning_html = f"""
        <div class="signal-summary">
            <div class="signal-summary__heading">What this means</div>
            {summary_html}
        </div>
        """

    insight_html = ""
    if show_insight:
        insight_html = f'<p class="rec-panel__insight">{html.escape(insight)}</p>'

    return f"""
    <div class="rec-panel card--elevated rec-panel--{style['tone']}">
        <div class="signal-badge signal-badge--{style['tone']}">{style['label']}</div>
        {insight_html}
        {meaning_html}
        <div class="rec-panel__confidence">
            <div class="rec-panel__conf-row">
                <span class="card__label">Signal strength</span>
                <span class="rec-panel__conf-value">{html.escape(confidence)} · {pct}%</span>
            </div>
            <div class="progress-track progress-track--lg">
                <div class="progress-fill progress-fill--{style['tone']}" style="width:{pct}%;"></div>
            </div>
        </div>
    </div>
    """


def risk_warning_banner(
    recommendation: str,
    confidence: str,
    score: float,
) -> str:
    pct = confidence_percent(confidence)
    if pct >= 70 or recommendation == "wait":
        return ""

    direction = recommendation.upper()
    return f"""
    <div class="risk-alert risk-alert--banner" role="alert">
        <strong>Heads up</strong>
        <span>
            Direction is {direction} (score {score:.0f}/100), but signal strength is only {pct}%.
            Read the summary below before entering — waiting is often the safer choice.
        </span>
    </div>
    """


def empty_state(*, title: str, description: str, compact: bool = False) -> str:
    cls = "state-panel state-panel--empty"
    if compact:
        cls += " state-panel--compact"
    return f"""
    <div class="{cls}">
        <div class="state-panel__icon">📊</div>
        <div class="state-panel__title">{html.escape(title)}</div>
        <p class="state-panel__desc">{html.escape(description)}</p>
    </div>
    """


def error_state(message: str) -> str:
    return f"""
    <div class="state-panel state-panel--error" role="alert">
        <div class="state-panel__title">Analysis failed</div>
        <p class="state-panel__desc">{html.escape(message)}</p>
    </div>
    """


def prose_block(text: str) -> str:
    return f'<div class="card card--prose card--elevated">{html.escape(text)}</div>'


def brand_footer(*, sources: str) -> str:
    return f"""
    <footer class="brand-footer">
        <p class="brand-footer__disclaimer">Educational tool only. Not financial advice.</p>
        <p class="brand-footer__meta">
            Built by {html.escape(BRAND['author_en'])} · {html.escape(BRAND['website_label'])} · v{html.escape(APP_VERSION)}
        </p>
        <p class="brand-footer__meta brand-footer__meta--muted">
            {html.escape(BRAND['product'])} · Data: {html.escape(sources)}
        </p>
    </footer>
    """


def data_hub_panel(hub: dict) -> str:
    if not hub:
        return empty_state(
            title="Data Hub unavailable",
            description="Run analysis to populate the unified data layer.",
            compact=True,
        )

    source_rows = []
    for name, info in (hub.get("source_status") or {}).items():
        status = html.escape(str(info.get("status", "offline")))
        updated = info.get("last_updated") or "—"
        error = info.get("error")
        status_cls = f"hub-status hub-status--{status}"
        error_html = f'<div class="hub-source__error">{html.escape(error)}</div>' if error else ""
        source_rows.append(
            f"""
            <div class="hub-source card card--elevated">
                <div class="hub-source__head">
                    <span class="hub-source__name">{html.escape(name)}</span>
                    <span class="{status_cls}">{status.upper()}</span>
                </div>
                <div class="hub-source__meta">Last updated: {html.escape(str(updated))}</div>
                {error_html}
            </div>
            """
        )

    available = ", ".join(hub.get("available_fields") or []) or "None"
    missing = ", ".join(hub.get("missing_fields") or []) or "None"
    quality = html.escape(str(hub.get("data_quality", "unknown")))
    impact = html.escape(str(hub.get("confidence_impact", "none")))
    last_updated = html.escape(str(hub.get("last_updated") or "—"))

    return f"""
    <div class="hub-panel">
        <div class="hub-summary card card--elevated">
            <div class="hub-summary__grid">
                <div><span class="card__label">Data quality</span><div class="hub-summary__value">{quality}</div></div>
                <div><span class="card__label">Last updated</span><div class="hub-summary__value">{last_updated}</div></div>
                <div><span class="card__label">Confidence impact</span><div class="hub-summary__value">{impact}</div></div>
                <div><span class="card__label">Active sources</span><div class="hub-summary__value">{len(hub.get("sources") or [])}</div></div>
            </div>
        </div>
        <div class="section-gap section-gap--sm"></div>
        <h4 class="section-heading">Connected Sources</h4>
        <div class="hub-source-grid">{''.join(source_rows)}</div>
        <div class="section-gap section-gap--sm"></div>
        <div class="hub-fields card card--prose card--elevated">
            <strong>Available data:</strong> {html.escape(available)}
            <br><br>
            <strong>Missing data:</strong> {html.escape(missing)}
        </div>
    </div>
    """


def stars_display(count: int, max_stars: int = 5) -> str:
    filled = max(0, min(max_stars, count))
    return "★" * filled + "☆" * (max_stars - filled)


def market_status_panel(*, trend: str, volatility: str, liquidity: str) -> str:
    items = [
        ("Market trend", trend, _status_tone(trend)),
        ("Volatility", volatility, _status_tone(volatility)),
        ("Liquidity", liquidity, _status_tone(liquidity)),
    ]
    cards = "".join(
        f"""
        <div class="card card--metric card--elevated card--tone-{tone}">
            <div class="card__label">{html.escape(label)}</div>
            <div class="card__value card__value--sm">{html.escape(value)}</div>
        </div>
        """
        for label, value, tone in items
    )
    return f'<div class="status-grid">{cards}</div>'


def _status_tone(value: str) -> str:
    lower = value.lower()
    if "bull" in lower:
        return "long"
    if "bear" in lower:
        return "short"
    if "high" in lower or "low" in lower:
        return "wait"
    return "wait"


def trade_quality_panel(*, grade: str, score: int, stars: int) -> str:
    tone = "long" if grade in {"A+", "A"} else "wait" if grade == "B" else "short" if grade == "C" else "wait"
    if grade == "No Trade":
        tone = "short"
    return f"""
    <div class="card card--elevated trade-quality card--tone-{tone}">
        <div class="card__label">Trade Quality</div>
        <div class="trade-quality__grade">{html.escape(grade)}</div>
        <div class="trade-quality__score">{score}/100</div>
        <div class="trade-quality__stars" aria-label="{stars} of 5 stars">{stars_display(stars)}</div>
    </div>
    """


def checklist_panel(*, title: str, items: list[str], positive: bool = True) -> str:
    cls = "checklist checklist--positive" if positive else "checklist checklist--negative"
    icon = "✓" if positive else "!"
    rows = "".join(
        f'<li class="checklist__item"><span class="checklist__icon">{icon}</span>{html.escape(item)}</li>'
        for item in items
    )
    return f"""
    <div class="card card--elevated {cls}">
        <div class="card__label">{html.escape(title)}</div>
        <ul class="checklist__list">{rows}</ul>
    </div>
    """


def source_status_panel(source_status: dict) -> str:
    if not source_status:
        return empty_state(title="No source status", description="Run analysis first.", compact=True)

    rows = []
    for name, status in source_status.items():
        status_str = html.escape(str(status))
        cls = f"hub-status hub-status--{status_str}"
        rows.append(
            f"""
            <div class="source-pill card card--elevated">
                <span class="source-pill__name">{html.escape(name)}</span>
                <span class="{cls}">{status_str.upper()}</span>
            </div>
            """
        )
    return f'<div class="source-status-grid">{"".join(rows)}</div>'


def fear_greed_panel(data: dict) -> str:
    if not data or data.get("value") is None:
        msg = html.escape(str(data.get("error") or "Fear & Greed data unavailable"))
        return f'<div class="card card--elevated card--prose">{msg}</div>'

    value = int(data["value"])
    tone = "long" if value >= 55 else "short" if value <= 45 else "wait"
    return f"""
    <div class="card card--elevated card--tone-{tone}">
        <div class="card__label">Fear &amp; Greed Index</div>
        <div class="card__value">{value}</div>
        <div class="card__detail">{html.escape(str(data.get("classification", "")))}</div>
        <div class="card__detail">Provider: {html.escape(str(data.get("provider", "Alternative.me")))}</div>
    </div>
    """


def news_sentiment_panel(data: dict) -> str:
    summary = data.get("summary") or {}
    headlines = data.get("headlines") or []
    headline_rows = "".join(
        f"""
        <li class="news-item news-item--{html.escape(str(item.get('sentiment', 'neutral')))}">
            <span class="news-item__source">{html.escape(str(item.get('source', '')))}</span>
            {html.escape(str(item.get('title', '')))}
        </li>
        """
        for item in headlines[:8]
    )
    if not headline_rows:
        headline_rows = "<li class='news-item'>No headlines fetched.</li>"

    return f"""
    <div class="card card--elevated news-panel">
        <div class="card__label">News Sentiment</div>
        <div class="news-panel__summary">
            {html.escape(str(summary.get('label', 'neutral')).title())}
            · score {summary.get('score', 50)}/100
            · +{summary.get('positive', 0)} / −{summary.get('negative', 0)} headlines
        </div>
        <ul class="news-panel__list">{headline_rows}</ul>
    </div>
    """


def risk_enhanced_panel(risk_profile: dict) -> str:
    if not risk_profile:
        return empty_state(title="Risk data unavailable", description="Run analysis first.", compact=True)

    return f"""
    <div class="card card--elevated risk-panel">
        <div class="risk-panel__grid">
            <div><span class="card__label">Risk Level</span><div class="card__value card__value--sm">{html.escape(str(risk_profile.get('level', 'N/A')))}</div></div>
            <div><span class="card__label">Probability</span><div class="card__value card__value--sm">{float(risk_profile.get('probability', 0)):.0%}</div></div>
            <div><span class="card__label">Invalidation</span><div class="card__value card__value--sm">${float(risk_profile.get('invalidation', 0)):,.2f}</div></div>
            <div><span class="card__label">Position (1% risk)</span><div class="card__value card__value--sm">{float(risk_profile.get('position_size_btc', 0)):.6f} BTC</div></div>
        </div>
        <p class="card__detail">Risk budget: ${float(risk_profile.get('risk_per_trade_usd', 0)):,.2f} · Notional: ${float(risk_profile.get('position_size_usd', 0)):,.2f}</p>
    </div>
    """


def placeholder_data_panel(title: str, payload: dict) -> str:
    rows = []
    for key, info in (payload or {}).items():
        if not isinstance(info, dict):
            continue
        status = html.escape(str(info.get("status", "unavailable")))
        message = html.escape(str(info.get("message") or info.get("provider") or ""))
        rows.append(
            f"""
            <div class="placeholder-row">
                <strong>{html.escape(key.replace('_', ' ').title())}</strong>
                <span class="hub-status hub-status--{status}">{status.upper()}</span>
                <div class="card__detail">{message}</div>
            </div>
            """
        )
    body = "".join(rows) or "<p class='card__detail'>No data available.</p>"
    return f"""
    <div class="card card--elevated card--prose">
        <div class="card__label">{html.escape(title)}</div>
        {body}
    </div>
    """
```

---

<a id="file-src-ui-styles-py"></a>
## File: `src/ui/styles.py`

```python
"""Global CSS — light/dark themes via CSS variables."""

from __future__ import annotations

from pathlib import Path

import streamlit as st

from src.ui.background import build_background_css, build_bitcoin_fallback_css, build_streamlit_surface_css, ensure_assets_dir
from src.ui.theme import RADIUS, SHADOW, SPACING, get_palette

# Project root (btc-market-analyzer/) — used for assets/background.jpg
_DEFAULT_PROJECT_ROOT = Path(__file__).resolve().parents[2]


def inject_global_styles(*, dark_mode: bool = True, project_root: Path | None = None) -> None:
    root = project_root or _DEFAULT_PROJECT_ROOT
    ensure_assets_dir(root)

    p = get_palette(dark_mode)
    background_css, has_background = build_background_css(root)
    if not has_background:
        background_css = build_bitcoin_fallback_css(dark_mode=dark_mode)
    surface_css = build_streamlit_surface_css()

    st.markdown(
        f"""
        <style>
        :root {{
            --bg: {p['bg']};
            --surface: {p['surface']};
            --surface-alt: {p['surface_alt']};
            --border: {p['border']};
            --text: {p['text']};
            --text-secondary: {p['text_secondary']};
            --text-muted: {p['text_muted']};
            --accent: {p['accent']};
            --accent-hover: {p['accent_hover']};
            --accent-soft: {p['accent_soft']};
            --long: {p['long']};
            --short: {p['short']};
            --wait: {p['wait']};
            --long-bg: {p['long_bg']};
            --short-bg: {p['short_bg']};
            --wait-bg: {p['wait_bg']};
            --long-border: {p['long_border']};
            --short-border: {p['short_border']};
            --wait-border: {p['wait_border']};
            --error-bg: {p['error_bg']};
            --error-border: {p['error_border']};
            --error-text: {p['error_text']};
            --space-xs: {SPACING['xs']};
            --space-sm: {SPACING['sm']};
            --space-md: {SPACING['md']};
            --space-lg: {SPACING['lg']};
            --space-xl: {SPACING['xl']};
            --radius: {RADIUS['md']};
            --radius-sm: {RADIUS['sm']};
            --radius-full: {RADIUS['full']};
            --shadow: {SHADOW['sm']};
            --shadow-md: {SHADOW['md']};
            --font: Inter, system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        }}

        .stApp {{
            background: var(--bg);
            font-family: var(--font);
            color: var(--text);
            overflow-x: clip;
        }}

        {background_css}

        {surface_css}

        .block-container {{
            padding-top: 0.5rem;
            padding-bottom: var(--space-lg);
            max-width: 1080px;
            margin-left: auto;
            margin-right: auto;
        }}

        .dashboard-shell {{
            width: 100%;
        }}

        .safety-banner {{
            text-align: center;
            font-size: 0.8125rem;
            font-weight: 600;
            color: var(--text-secondary);
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            padding: 0.625rem 1rem;
            margin: 0 0 var(--space-md);
            box-shadow: var(--shadow);
        }}

        /* ── Premium sticky navigation ── */
        .premium-nav-outer {{
            margin-left: calc(50% - 50vw);
            margin-right: calc(50% - 50vw);
            width: 100vw;
            max-width: 100vw;
            box-sizing: border-box;
            position: sticky;
            top: 0;
            z-index: 999;
            margin-bottom: var(--space-lg);
        }}
        .premium-nav {{
            background: linear-gradient(165deg, #3D2614 0%, #2A1A0E 40%, #1A1108 100%);
            box-shadow: 0 4px 24px rgba(0, 0, 0, 0.22),
                        0 1px 0 rgba(247, 147, 26, 0.12) inset;
            border-bottom: 1px solid rgba(247, 147, 26, 0.2);
        }}
        .premium-nav__inner {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: var(--space-lg);
            max-width: 1080px;
            margin: 0 auto;
            padding: clamp(1rem, 3vw, 1.375rem) clamp(1rem, 4vw, 1.5rem);
            box-sizing: border-box;
        }}
        .premium-nav__left {{
            display: flex;
            align-items: center;
            gap: 0.875rem;
            min-width: 0;
            flex: 1;
        }}
        .premium-nav__logo {{
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.4rem;
            width: auto;
            min-height: 2.75rem;
            padding: 0 0.875rem;
            flex-shrink: 0;
            border-radius: var(--radius-sm);
            background: rgba(247, 147, 26, 0.12);
            border: 1px solid rgba(247, 147, 26, 0.28);
            color: #f7931a;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }}
        .premium-nav__logo-symbol {{
            font-size: 1.25rem;
            font-weight: 700;
            line-height: 1;
        }}
        .premium-nav__logo-text {{
            font-size: 0.9375rem;
            font-weight: 700;
            letter-spacing: 0.03em;
            line-height: 1;
            color: #FFF4E6;
        }}
        .premium-nav__logo:hover {{
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(247, 147, 26, 0.2);
        }}
        .premium-nav__brand {{
            min-width: 0;
        }}
        .premium-nav__tagline {{
            font-family: var(--font);
            font-size: clamp(0.8125rem, 1.9vw, 0.9375rem);
            font-weight: 500;
            letter-spacing: 0.04em;
            line-height: 1.35;
            color: #D4A574;
            margin: 0.375rem 0 0;
            padding: 0;
            text-transform: none;
        }}
        .premium-nav__author {{
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 0.35rem 0.5rem;
            font-family: var(--font);
            font-size: clamp(0.75rem, 1.7vw, 0.8125rem);
            font-weight: 500;
            line-height: 1.45;
            color: #94a3b8;
            margin: 0.25rem 0 0;
            padding: 0;
            max-width: 100%;
        }}
        .premium-nav__author-name {{
            color: #cbd5e1;
            font-weight: 600;
        }}
        .premium-nav__subtitle {{
            display: none;
        }}
        .premium-nav__title {{
            font-family: var(--font);
            font-size: clamp(1.125rem, 3vw, 1.625rem);
            font-weight: 700;
            letter-spacing: -0.03em;
            line-height: 1.2;
            color: #ffffff;
            margin: 0;
            padding: 0;
            white-space: normal;
            overflow: visible;
            text-overflow: unset;
        }}
        .premium-nav__meta {{
            display: none;
        }}
        .premium-nav__sep {{
            color: #475569;
            user-select: none;
        }}
        .premium-nav__link {{
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            color: #cbd5e1;
            text-decoration: none;
            transition: color 0.18s ease;
        }}
        .premium-nav__link:hover {{
            color: #ffffff;
            text-decoration: underline;
            text-underline-offset: 2px;
        }}
        .premium-nav__globe {{
            font-size: 0.8125em;
            line-height: 1;
        }}
        .premium-nav__version {{
            color: #64748b;
        }}
        .premium-nav__right {{
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 0.375rem;
            flex-shrink: 0;
        }}
        .premium-nav__status {{
            display: inline-flex;
            align-items: center;
            gap: 0.4375rem;
            font-size: 0.75rem;
            font-weight: 600;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            color: #e2e8f0;
        }}
        .status-dot {{
            width: 7px;
            height: 7px;
            border-radius: 50%;
            flex-shrink: 0;
        }}
        .status-dot--live {{
            background: #22c55e;
            box-shadow: 0 0 0 2px rgba(34, 197, 94, 0.25);
            animation: pulse-dot 2s ease infinite;
        }}
        .status-dot--idle {{
            background: #64748b;
            box-shadow: 0 0 0 2px rgba(100, 116, 139, 0.25);
        }}
        @keyframes pulse-dot {{
            0%, 100% {{ opacity: 1; }}
            50% {{ opacity: 0.55; }}
        }}
        .premium-nav__updated {{
            font-size: 0.6875rem;
            color: #64748b;
            text-align: right;
            line-height: 1.4;
            max-width: 14rem;
        }}
        .premium-nav__updated-label {{
            color: #94a3b8;
            font-weight: 500;
            margin-right: 0.25rem;
        }}
        .premium-nav__divider {{
            height: 2px;
            background: linear-gradient(
                90deg,
                transparent 0%,
                rgba(99, 102, 241, 0.5) 25%,
                rgba(247, 147, 26, 0.45) 50%,
                rgba(99, 102, 241, 0.5) 75%,
                transparent 100%
            );
        }}

        /* ── Layout spacing ── */
        .section-gap {{ height: var(--space-md); }}
        .section-gap--sm {{ height: var(--space-sm); }}
        .section-heading {{
            font-size: 0.9375rem;
            font-weight: 600;
            color: var(--text);
            margin: 0 0 var(--space-md);
            letter-spacing: -0.01em;
        }}

        /* ── Cards ── */
        .card-wrap {{
            height: 100%;
            display: flex;
        }}
        .card-wrap .card {{
            flex: 1;
            width: 100%;
        }}
        .card {{
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 1.125rem 1.25rem;
            box-sizing: border-box;
            transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
        }}
        .card--elevated {{
            box-shadow: var(--shadow);
        }}
        .card--elevated:hover {{
            box-shadow: var(--shadow-md);
            transform: translateY(-1px);
        }}
        .card--metric {{
            min-height: 6.5rem;
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-align: center;
        }}
        .card--component {{
            min-height: 9rem;
            margin-bottom: var(--space-sm);
        }}
        .card--tone-long {{ border-left: 3px solid var(--long); }}
        .card--tone-short {{ border-left: 3px solid var(--short); }}
        .card--tone-wait {{ border-left: 3px solid var(--wait); }}
        .card__label {{
            font-size: 0.6875rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.07em;
            color: var(--text-muted);
            margin-bottom: 0.5rem;
        }}
        .card__value {{
            font-size: clamp(1.125rem, 2.8vw, 1.5rem);
            font-weight: 700;
            color: var(--text);
            line-height: 1.2;
            letter-spacing: -0.02em;
        }}
        .card--tone-long .card__value {{ color: var(--long); }}
        .card--tone-short .card__value {{ color: var(--short); }}
        .card--tone-wait .card__value {{ color: var(--wait); }}
        .card__suffix {{
            font-size: 0.6em;
            font-weight: 600;
            color: var(--text-muted);
        }}
        .card__detail {{
            font-size: 0.8125rem;
            color: var(--text-secondary);
            line-height: 1.55;
            margin: 0.375rem 0 0;
        }}
        .card--prose {{
            font-size: 0.875rem;
            color: var(--text-secondary);
            line-height: 1.75;
            white-space: pre-wrap;
        }}

        /* ── Recommendation panel ── */
        .rec-panel {{
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 1.25rem 1.375rem;
            box-shadow: var(--shadow);
            min-height: 18rem;
            display: flex;
            flex-direction: column;
            gap: var(--space-md);
            align-items: stretch;
        }}
        .rec-panel--long {{ border-top: 4px solid var(--long); }}
        .rec-panel--short {{ border-top: 4px solid var(--short); }}
        .rec-panel--wait {{ border-top: 4px solid var(--wait); }}
        .signal-badge {{
            display: flex;
            align-items: center;
            justify-content: center;
            align-self: center;
            width: 100%;
            max-width: 16rem;
            padding: 0.85rem 1.25rem;
            border-radius: var(--radius-sm);
            font-size: clamp(1.75rem, 4vw, 2.25rem);
            font-weight: 800;
            letter-spacing: 0.14em;
            text-align: center;
        }}
        .signal-badge--long {{
            color: var(--long);
            background: var(--long-bg);
            border: 2px solid var(--long-border);
            box-shadow: 0 8px 24px rgba(5, 150, 105, 0.15);
        }}
        .signal-badge--short {{
            color: var(--short);
            background: var(--short-bg);
            border: 2px solid var(--short-border);
            box-shadow: 0 8px 24px rgba(220, 38, 38, 0.15);
        }}
        .signal-badge--wait {{
            color: var(--wait);
            background: var(--wait-bg);
            border: 2px solid var(--wait-border);
            box-shadow: 0 8px 24px rgba(217, 119, 6, 0.15);
        }}
        .rec-panel__badge {{
            display: none;
        }}
        .rec-panel__insight {{
            font-size: 0.9375rem;
            color: var(--text-secondary);
            line-height: 1.65;
            margin: 0;
            text-align: center;
        }}
        .rec-panel__conf-row {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.375rem;
        }}
        .rec-panel__conf-value {{
            font-size: 0.8125rem;
            font-weight: 600;
            color: var(--text);
        }}

        .signal-summary {{
            margin-top: 1rem;
            text-align: left;
            display: flex;
            flex-direction: column;
            gap: 0.625rem;
            width: 100%;
        }}
        .signal-summary__heading {{
            font-size: 0.6875rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--text-muted);
            margin-bottom: 0.125rem;
        }}
        .signal-summary__row {{
            padding: 0.75rem 0.875rem;
            background: var(--surface-alt);
            border-radius: var(--radius-sm);
            border: 1px solid var(--border);
        }}
        .signal-summary__label {{
            font-size: 0.6875rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: var(--text-muted);
            margin-bottom: 0.25rem;
        }}
        .signal-summary__text {{
            font-size: 0.875rem;
            line-height: 1.55;
            color: var(--text-secondary);
            margin: 0;
        }}

        .risk-alert {{
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
            padding: 0.75rem 0.875rem;
            border-radius: var(--radius-sm);
            background: var(--wait-bg);
            border: 1px solid var(--wait-border);
            color: var(--wait);
            font-size: 0.8125rem;
            line-height: 1.45;
        }}
        .risk-alert strong {{
            font-size: 0.875rem;
            font-weight: 700;
        }}
        .risk-alert--banner {{
            margin-bottom: var(--space-md);
        }}

        /* ── Progress bars ── */
        .progress-track {{
            background: var(--surface-alt);
            border-radius: var(--radius-sm);
            height: 5px;
            overflow: hidden;
        }}
        .progress-track--lg {{ height: 8px; }}
        .progress-fill {{
            height: 100%;
            border-radius: var(--radius-sm);
            transition: width 0.4s ease;
        }}
        .progress-fill--long {{ background: var(--long); }}
        .progress-fill--short {{ background: var(--short); }}
        .progress-fill--wait {{ background: var(--wait); }}

        /* ── State panels ── */
        .state-panel {{
            text-align: center;
            background: var(--surface);
            border-radius: var(--radius);
            padding: 2.5rem 1.5rem;
            border: 1px dashed var(--border);
        }}
        .state-panel--compact {{ padding: 1.5rem; }}
        .state-panel--error {{
            text-align: left;
            border: 1px solid var(--error-border);
            background: var(--error-bg);
            color: var(--error-text);
        }}
        .state-panel__icon {{ font-size: 2rem; margin-bottom: 0.5rem; opacity: 0.7; }}
        .state-panel__title {{ font-size: 1rem; font-weight: 600; margin-bottom: 0.25rem; }}
        .state-panel__desc {{
            font-size: 0.875rem;
            color: var(--text-secondary);
            line-height: 1.6;
            max-width: 28rem;
            margin: 0 auto;
        }}
        .state-panel--error .state-panel__desc {{ color: var(--error-text); margin: 0; }}

        /* ── Brand footer ── */
        .brand-footer {{
            text-align: center;
            padding: var(--space-md) 0 var(--space-sm);
            border-top: 1px solid var(--border);
            margin-top: var(--space-sm);
        }}
        .brand-footer__disclaimer {{
            font-size: 0.8125rem;
            font-weight: 600;
            color: var(--text-secondary);
            margin: 0 0 0.375rem;
        }}
        .brand-footer__meta {{
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0.375rem 0 0;
        }}

        .brand-footer__meta--muted {{
            color: var(--text-muted);
            font-weight: 400;
        }}

        /* ── Data Hub ── */
        .hub-panel {{ width: 100%; }}
        .hub-summary__grid {{
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: var(--space-md);
        }}
        .hub-summary__value {{
            font-size: 0.9375rem;
            font-weight: 700;
            color: var(--text);
            margin-top: 0.35rem;
        }}
        .hub-source-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: var(--space-sm);
        }}
        .hub-source {{
            padding: 0.875rem 1rem;
            min-height: 5.5rem;
        }}
        .hub-source__head {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 0.5rem;
            margin-bottom: 0.35rem;
        }}
        .hub-source__name {{
            font-weight: 600;
            color: var(--text);
            font-size: 0.875rem;
        }}
        .hub-source__meta {{
            font-size: 0.75rem;
            color: var(--text-muted);
        }}
        .hub-source__error {{
            margin-top: 0.35rem;
            font-size: 0.6875rem;
            color: var(--text-secondary);
            line-height: 1.4;
        }}
        .hub-status {{
            font-size: 0.625rem;
            font-weight: 700;
            letter-spacing: 0.06em;
            padding: 0.2rem 0.45rem;
            border-radius: var(--radius-full);
        }}
        .hub-status--online {{ background: var(--long-bg); color: var(--long); }}
        .hub-status--degraded {{ background: var(--wait-bg); color: var(--wait); }}
        .hub-status--offline {{ background: var(--short-bg); color: var(--short); }}
        .hub-status--placeholder {{ background: var(--surface-alt); color: var(--text-muted); }}

        /* ── Sidebar ── */
        [data-testid="stSidebar"] {{
            background: var(--surface);
            border-right: 1px solid var(--border);
        }}
        .sidebar-label {{
            font-size: 0.6875rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--text-muted);
            margin-bottom: 0.75rem;
        }}

        /* ── Tabs ── */
        .stTabs [data-baseweb="tab-list"] {{
            gap: 0.375rem;
            background: transparent;
            border-bottom: 1px solid var(--border);
            padding-bottom: 0.25rem;
        }}
        .stTabs [data-baseweb="tab"] {{
            font-family: var(--font);
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--text-secondary);
            padding: 0.5rem 1rem;
            border-radius: var(--radius-sm) var(--radius-sm) 0 0;
        }}
        .stTabs [aria-selected="true"] {{
            color: var(--accent) !important;
            background: var(--accent-soft);
        }}

        /* ── Buttons ── */
        .stButton > button {{
            min-height: 44px !important;
            border-radius: var(--radius-sm) !important;
            font-family: var(--font) !important;
            font-weight: 600 !important;
        }}
        .stButton > button[kind="primary"],
        .stButton > button[data-testid="baseButton-primary"] {{
            background: var(--accent) !important;
            color: #fff !important;
            border: none !important;
            box-shadow: 0 2px 8px rgba(247, 147, 26, 0.35) !important;
        }}
        .stButton > button[kind="primary"]:hover {{
            background: var(--accent-hover) !important;
        }}

        [data-testid="stExpander"] {{
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
        }}

        [data-testid="stSelectbox"] label,
        [data-testid="stTextInput"] label,
        [data-testid="stSlider"] label,
        [data-testid="stNumberInput"] label,
        [data-testid="stToggle"] label {{
            font-size: 0.8125rem !important;
            color: var(--text-secondary) !important;
        }}

        [data-testid="stVerticalBlock"] > div[data-testid="stVerticalBlock"] {{
            gap: 0.35rem;
        }}

        div[data-testid="stPlotlyChart"] {{
            margin-top: 0.25rem;
            margin-bottom: 0.25rem;
        }}

        #MainMenu {{ visibility: hidden; }}
        footer {{ visibility: hidden; }}

        @media (max-width: 768px) {{
            .premium-nav__inner {{
                flex-direction: column;
                align-items: flex-start;
                gap: var(--space-md);
            }}
            .premium-nav__right {{
                flex-direction: row;
                align-items: center;
                justify-content: space-between;
                width: 100%;
                padding-top: 0.25rem;
                border-top: 1px solid rgba(255, 255, 255, 0.06);
            }}
            .premium-nav__updated {{
                text-align: left;
                max-width: none;
            }}
            .premium-nav__title {{
                white-space: normal;
            }}
            .rec-panel {{ min-height: auto; }}
            .hub-summary__grid {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
            [data-testid="column"] {{ min-width: calc(50% - 0.5rem) !important; }}
        }}
        @media (max-width: 540px) {{
            [data-testid="column"] {{ min-width: 100% !important; }}
            .hub-summary__grid {{ grid-template-columns: 1fr; }}
        }}

        @media (prefers-reduced-motion: reduce) {{
            .progress-fill {{ transition: none; }}
            .status-dot--live {{ animation: none; }}
            .premium-nav__logo:hover {{ transform: none; }}
            .card:hover, .card--elevated:hover, .rec-panel:hover {{ transform: none; }}
        }}

        /* ── AI dashboard panels ── */
        .status-grid {{
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: var(--space-md);
        }}
        .source-status-grid {{
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: var(--space-sm);
        }}
        .source-pill {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 0.5rem;
            padding: 0.75rem 0.875rem;
        }}
        .source-pill__name {{
            font-size: 0.8125rem;
            font-weight: 600;
            color: var(--text);
        }}
        .trade-quality {{
            text-align: center;
            padding: 1.25rem;
        }}
        .trade-quality__grade {{
            font-size: 2.5rem;
            font-weight: 800;
            line-height: 1.1;
            margin: 0.25rem 0;
        }}
        .trade-quality__score {{
            font-size: 1rem;
            color: var(--text-secondary);
            margin-bottom: 0.35rem;
        }}
        .trade-quality__stars {{
            font-size: 1.25rem;
            letter-spacing: 0.15em;
            color: #fbbf24;
        }}
        .checklist__list {{
            list-style: none;
            margin: 0.5rem 0 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }}
        .checklist__item {{
            display: flex;
            gap: 0.5rem;
            align-items: flex-start;
            font-size: 0.875rem;
            line-height: 1.45;
            color: var(--text-secondary);
        }}
        .checklist--positive .checklist__icon {{ color: var(--long); font-weight: 700; }}
        .checklist--negative .checklist__icon {{ color: var(--wait); font-weight: 700; }}
        .news-panel__summary {{
            font-size: 0.875rem;
            color: var(--text-secondary);
            margin: 0.35rem 0 0.75rem;
        }}
        .news-panel__list {{
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }}
        .news-item {{
            font-size: 0.8125rem;
            line-height: 1.45;
            color: var(--text-secondary);
            padding: 0.5rem 0;
            border-top: 1px solid var(--border);
        }}
        .news-item__source {{
            display: block;
            font-size: 0.6875rem;
            font-weight: 700;
            text-transform: uppercase;
            color: var(--text-muted);
            margin-bottom: 0.15rem;
        }}
        .news-item--positive {{ border-left: 3px solid var(--long); padding-left: 0.5rem; }}
        .news-item--negative {{ border-left: 3px solid var(--short); padding-left: 0.5rem; }}
        .risk-panel__grid {{
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: var(--space-md);
        }}
        .placeholder-row {{
            padding: 0.5rem 0;
            border-top: 1px solid var(--border);
        }}
        .card__value--sm {{
            font-size: 1.05rem !important;
        }}

        /* ── Overview tab ── */
        .overview-tab [data-testid="column"],
        .overview-tab [data-testid="stVerticalBlock"],
        .overview-tab [data-testid="stPlotlyChart"],
        .overview-tab [data-testid="stPlotlyChart"] > div,
        .overview-tab .js-plotly-plot,
        .overview-tab .plot-container {{
            background: transparent !important;
        }}
        .overview-tab .card,
        .overview-tab .rec-panel {{
            background: rgba(42, 26, 14, 0.72) !important;
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(247, 147, 26, 0.2) !important;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
        }}
        .overview-tab .rec-panel {{
            min-height: auto;
        }}
        .overview-signal-only {{
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 18rem;
            background: transparent !important;
            border: none !important;
            box-shadow: none !important;
            padding: 0;
        }}
        .overview-tab [data-testid="stHtml"] {{
            background: transparent !important;
        }}
        .overview-tab .progress-track {{
            background: rgba(255, 255, 255, 0.08) !important;
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )
```

---

<a id="file-src-ui-background-py"></a>
## File: `src/ui/background.py`

```python
"""Local background image loading for custom page styling."""

from __future__ import annotations

import base64
from pathlib import Path

PRIMARY_BACKGROUND = "background.jpg"

BACKGROUND_FILENAMES = (
    "background.jpg",
    "background.jpeg",
    "background.png",
    "background.webp",
)

MIME_BY_SUFFIX = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
}

# Warm Bitcoin-tinted overlay for readable text over the photo
OVERLAY_RGBA = "rgba(26, 17, 8, 0.52)"


def ensure_assets_dir(project_root: Path) -> Path:
    """Create the assets folder if it does not exist."""
    assets_dir = project_root / "assets"
    assets_dir.mkdir(parents=True, exist_ok=True)
    return assets_dir


def find_background_image(project_root: Path) -> Path | None:
    """Return assets/background.jpg if present, otherwise any supported image."""
    assets_dir = ensure_assets_dir(project_root)

    primary = assets_dir / PRIMARY_BACKGROUND
    if primary.is_file() and primary.stat().st_size > 0:
        return primary

    for name in BACKGROUND_FILENAMES:
        if name == PRIMARY_BACKGROUND:
            continue
        candidate = assets_dir / name
        if candidate.is_file() and candidate.stat().st_size > 0:
            return candidate
    return None


def _to_data_uri(image_path: Path) -> str | None:
    try:
        mime = MIME_BY_SUFFIX.get(image_path.suffix.lower(), "image/jpeg")
        encoded = base64.b64encode(image_path.read_bytes()).decode("ascii")
        return f"data:{mime};base64,{encoded}"
    except OSError:
        return None


def build_background_css(project_root: Path | None) -> tuple[str, bool]:
    """
    Build CSS for a fixed full-page background with dark overlay and glass cards.
    Returns (css_fragment, has_background). Safe when the image file is missing.
    """
    if project_root is None:
        return "", False

    image_path = find_background_image(project_root)
    if image_path is None:
        return "", False

    data_uri = _to_data_uri(image_path)
    if data_uri is None:
        return "", False

    css = f"""
        :root {{
            --glass-bg: rgba(42, 26, 14, 0.58);
            --glass-bg-hover: rgba(42, 26, 14, 0.72);
            --glass-border: rgba(247, 147, 26, 0.22);
            --glass-border-hover: rgba(247, 147, 26, 0.45);
            --glass-blur: 18px;
            --glass-shadow: 0 8px 32px rgba(0, 0, 0, 0.28);
            --glass-shadow-hover: 0 14px 40px rgba(247, 147, 26, 0.12);
            --surface: var(--glass-bg);
            --surface-alt: rgba(247, 147, 26, 0.08);
            --border: var(--glass-border);
            --bg: transparent;
        }}

        .stApp {{
            background-color: #1A1108;
            background-image:
                radial-gradient(ellipse 70% 45% at 50% -10%, rgba(247, 147, 26, 0.15), transparent),
                linear-gradient({OVERLAY_RGBA}, {OVERLAY_RGBA}),
                url("{data_uri}");
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: var(--font);
            color: #f8fafc;
            overflow-x: clip;
        }}

        .block-container,
        [data-testid="stAppViewContainer"],
        [data-testid="stMain"] {{
            background: transparent !important;
        }}

        .card,
        .rec-panel,
        .state-panel,
        .card--prose,
        .safety-banner,
        .hub-source,
        .hub-summary,
        .hub-fields,
        .risk-alert,
        [data-testid="stExpander"],
        .brand-footer {{
            background: var(--glass-bg) !important;
            backdrop-filter: blur(var(--glass-blur));
            -webkit-backdrop-filter: blur(var(--glass-blur));
            border: 1px solid var(--glass-border) !important;
            box-shadow: var(--glass-shadow);
            transition: transform 0.22s ease, box-shadow 0.22s ease,
                        border-color 0.22s ease, background 0.22s ease;
        }}

        .card:hover,
        .rec-panel:hover,
        .state-panel--empty:hover,
        .hub-source:hover {{
            transform: translateY(-2px);
            box-shadow: var(--glass-shadow-hover);
            border-color: var(--glass-border-hover) !important;
            background: var(--glass-bg-hover) !important;
        }}

        [data-testid="stSidebar"] > div:first-child {{
            background: rgba(42, 26, 14, 0.78) !important;
            backdrop-filter: blur(var(--glass-blur));
            -webkit-backdrop-filter: blur(var(--glass-blur));
            border-right: 1px solid rgba(247, 147, 26, 0.18) !important;
        }}

        .stTabs [data-baseweb="tab-list"] {{
            background: rgba(42, 26, 14, 0.42) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: var(--radius-sm);
            padding: 0.25rem 0.375rem;
        }}

        @media (max-width: 768px) {{
            .stApp {{
                background-attachment: scroll;
            }}
        }}
    """
    return css, True


def build_bitcoin_fallback_css(*, dark_mode: bool = True) -> str:
    """Bitcoin-themed page background when no custom image is loaded."""
    if dark_mode:
        return """
        .stApp {
            background-color: #1A1108 !important;
            background-image:
                radial-gradient(ellipse 80% 50% at 50% -15%, rgba(247, 147, 26, 0.22), transparent),
                radial-gradient(ellipse 55% 40% at 100% 80%, rgba(242, 169, 0, 0.10), transparent),
                radial-gradient(ellipse 40% 30% at 0% 60%, rgba(247, 147, 26, 0.08), transparent),
                linear-gradient(180deg, #1A1108 0%, #0f0a06 45%, #1C1209 100%) !important;
            background-attachment: fixed;
        }
        """
    return """
        .stApp {
            background-color: #FFF4E6 !important;
            background-image:
                radial-gradient(ellipse 80% 50% at 50% 0%, rgba(247, 147, 26, 0.14), transparent),
                linear-gradient(180deg, #FFF8F0 0%, #FFEED9 55%, #FFDDB3 100%) !important;
            background-attachment: fixed;
        }
        """


def build_streamlit_surface_css() -> str:
    """Remove Streamlit default white backgrounds."""
    return """
        [data-testid="stAppViewContainer"],
        [data-testid="stMain"],
        [data-testid="stHeader"],
        section.main,
        .block-container {
            background: transparent !important;
        }
        [data-testid="stSidebar"] {
            background: var(--surface) !important;
            border-right: 1px solid var(--border) !important;
        }
        [data-testid="stSidebar"] > div:first-child {
            background: var(--surface) !important;
        }
        iframe {
            border-radius: var(--radius-sm);
        }
    """
```

---

<a id="file-src-ui-charts-py"></a>
## File: `src/ui/charts.py`

```python
"""Theme-aware Plotly charts."""

from __future__ import annotations

from typing import TYPE_CHECKING

import plotly.graph_objects as go
import streamlit as st

from src.ui.theme import PLOTLY_CONFIG, chart_layout, gauge_steps, get_palette, score_color

if TYPE_CHECKING:
    from src.analysis.models import AnalysisResult

_GAUGE_HEIGHT = 340
_HEATMAP_HEIGHT = 400


def render_score_gauge(score: float, *, dark: bool = False) -> None:
    palette = get_palette(dark)
    fig = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=score,
            number={
                "suffix": "/100",
                "font": {"size": 42, "color": palette["text"], "family": "Inter, system-ui, sans-serif"},
            },
            title={"text": "Composite Score", "font": {"size": 14, "color": palette["text_secondary"]}},
            gauge={
                "axis": {
                    "range": [0, 100],
                    "tickmode": "array",
                    "tickvals": [19, 50, 81],
                    "ticktext": ["Weak", "Neutral", "Strong"],
                    "tickcolor": palette["text_muted"],
                    "tickfont": {"size": 12, "color": palette["text_secondary"]},
                },
                "bar": {"color": score_color(score, dark), "thickness": 0.72},
                "bgcolor": palette["surface_alt"],
                "borderwidth": 0,
                "steps": gauge_steps(dark),
            },
        )
    )
    layout = chart_layout(palette)
    layout["margin"] = {"l": 24, "r": 24, "t": 56, "b": 36}
    fig.update_layout(height=_GAUGE_HEIGHT, **layout)
    st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CONFIG)


def render_heatmap_chart(result: AnalysisResult, *, dark: bool = False) -> None:
    palette = get_palette(dark)
    heatmap = result.heatmap
    if heatmap is None or heatmap.empty:
        return

    intensity_col = "intensity" if "intensity" in heatmap.columns else "volume"
    fig = go.Figure(
        go.Bar(
            x=heatmap[intensity_col],
            y=heatmap["price_level"],
            orientation="h",
            marker=dict(
                color=heatmap[intensity_col],
                colorscale=[
                    [0, palette["surface_alt"]],
                    [0.5, palette["heatmap_mid"]],
                    [1, palette["short"]],
                ],
                showscale=True,
                colorbar=dict(title="Intensity", thickness=10, len=0.55, outlinewidth=0),
            ),
            hovertemplate="Price: $%{y:,.0f}<br>Intensity: %{x:.2f}<extra></extra>",
        )
    )
    fig.add_hline(
        y=result.price,
        line_dash="dash",
        line_color=palette["accent"],
        line_width=1.5,
        annotation_text=f"${result.price:,.0f}",
        annotation_font=dict(color=palette["accent"], size=10),
    )
    fig.update_layout(
        height=_HEATMAP_HEIGHT,
        title=dict(text=result.heatmap_source, font=dict(size=12, color=palette["text_muted"])),
        xaxis_title="Intensity",
        yaxis_title="Price (USD)",
        **chart_layout(palette),
    )
    st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CONFIG)
```

---

<a id="file-src-ui-sidebar-py"></a>
## File: `src/ui/sidebar.py`

```python
"""Sidebar settings and controls."""

from __future__ import annotations

import os
from dataclasses import dataclass

import streamlit as st

__all__ = ["SidebarSettings", "render_sidebar"]

AUTO_REFRESH_SECONDS = 60
AUTO_TIMEFRAME = "1m"
DEFAULT_ACCOUNT_SIZE = 10_000.0


@dataclass
class SidebarSettings:
    symbol: str
    interval: str
    api_key: str
    dark_mode: bool
    analyze_clicked: bool
    auto_refresh: bool
    refresh_seconds: int
    risk_settings: dict[str, float]


def render_sidebar() -> SidebarSettings:
    """Return sidebar configuration and whether Analyze was clicked."""
    if "max_risk_pct" not in st.session_state:
        st.session_state.max_risk_pct = 1.0

    with st.sidebar:
        st.markdown('<p class="sidebar-label">Market</p>', unsafe_allow_html=True)
        symbol = st.selectbox("Symbol", ["BTCUSDT"], index=0)
        st.caption(f"Timeframe: {AUTO_TIMEFRAME} (fixed)")

        st.markdown("---")
        analyze_clicked = st.button("Analyze Market", type="primary", use_container_width=True)
        st.caption(f"Auto refresh: every {AUTO_REFRESH_SECONDS} seconds")

        st.markdown("---")
        st.markdown('<p class="sidebar-label">Risk Settings</p>', unsafe_allow_html=True)
        max_risk_pct = st.slider(
            "Max risk per trade (%)",
            min_value=0.25,
            max_value=5.0,
            value=float(st.session_state.max_risk_pct),
            step=0.25,
            help="Used for position sizing estimates in the Risk tab.",
        )
        st.session_state.max_risk_pct = max_risk_pct

        st.markdown("---")
        st.markdown('<p class="sidebar-label">Data</p>', unsafe_allow_html=True)
        api_key = st.text_input(
            "Coinglass API Key (optional)",
            value=os.getenv("COINGLASS_API_KEY", ""),
            type="password",
            help="Enables liquidation heatmap and enriched derivatives data.",
        )

    return SidebarSettings(
        symbol=symbol,
        interval=AUTO_TIMEFRAME,
        api_key=api_key,
        dark_mode=True,
        analyze_clicked=analyze_clicked,
        auto_refresh=True,
        refresh_seconds=AUTO_REFRESH_SECONDS,
        risk_settings={
            "max_risk_pct": max_risk_pct,
            "account_size": DEFAULT_ACCOUNT_SIZE,
        },
    )
```

---

<a id="file-src-ui-dashboard-py"></a>
## File: `src/ui/dashboard.py`

```python
"""Tabbed dashboard layout."""

from __future__ import annotations

from typing import TYPE_CHECKING

import streamlit as st

from src.ui.charts import render_score_gauge
from src.ui.helpers import indicator_rows, signal_plain_language_summary
from src.ui.primitives import (
    brand_footer,
    checklist_panel,
    component_card,
    empty_state,
    metric_card,
    metric_card_wrap,
    prose_block,
    risk_enhanced_panel,
    risk_warning_banner,
    section_heading,
    trade_quality_panel,
)
from src.ui.theme import RECOMMENDATION_STYLE, confidence_percent
from src.ui.tradingview import render_tradingview_chart

if TYPE_CHECKING:
    from src.analysis.models import AnalysisResult


def _render_metric_row(cards: list[str], columns: int = 4) -> None:
    cols = st.columns(columns, gap="medium")
    for col, card in zip(cols, cards, strict=False):
        with col:
            st.markdown(metric_card_wrap(card), unsafe_allow_html=True)


def _insights(result: AnalysisResult):
    return result.insights


def render_ai_dashboard_tab(result: AnalysisResult, *, dark: bool) -> None:
    interval = st.session_state.get("chart_interval", "1m")
    st.markdown(section_heading("Live Chart"), unsafe_allow_html=True)
    render_tradingview_chart(interval=interval, dark=dark)

    st.markdown("<div class='section-gap section-gap--sm'></div>", unsafe_allow_html=True)

    insights = _insights(result)
    if insights:
        st.markdown(
            trade_quality_panel(
                grade=insights.trade_quality.grade,
                score=insights.trade_quality.score,
                stars=insights.trade_quality.stars,
            ),
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            empty_state(title="Insights loading", description="Run analysis to populate AI dashboard panels.", compact=True),
            unsafe_allow_html=True,
        )


def render_overview_tab(result: AnalysisResult, *, dark: bool) -> None:
    style = RECOMMENDATION_STYLE[result.recommendation]

    st.markdown('<div class="overview-tab">', unsafe_allow_html=True)

    _render_metric_row([
        metric_card("Price", f"${result.price:,.2f}"),
        metric_card("Direction", style["label"], tone=style["tone"]),
        metric_card("Signal strength", f"{result.confidence} · {confidence_percent(result.confidence)}%"),
        metric_card("Risk / Reward", f"{result.risk_reward:.2f}", tone="long" if result.risk_reward >= 1.5 else "wait"),
    ])

    st.markdown("<div class='section-gap section-gap--sm'></div>", unsafe_allow_html=True)

    left, right = st.columns([1.15, 1], gap="large")
    with left:
        render_score_gauge(result.score, dark=dark)
    with right:
        badge_html = (
            f'<div class="overview-signal-only">'
            f'<div class="signal-badge signal-badge--{style["tone"]}">{style["label"]}</div>'
            f"</div>"
        )
        if hasattr(st, "html"):
            st.html(badge_html)
        else:
            st.markdown(badge_html, unsafe_allow_html=True)

    st.markdown("</div>", unsafe_allow_html=True)


def render_trade_setup_tab(result: AnalysisResult) -> None:
    st.markdown(section_heading("Trade Levels"), unsafe_allow_html=True)
    tps = result.take_profits or {}
    _render_metric_row([
        metric_card("Entry Price", f"${result.price:,.2f}"),
        metric_card("Stop Loss", f"${result.stop_loss:,.2f}", tone="short"),
        metric_card("TP1", f"${tps.get('tp1', result.take_profit):,.2f}", tone="long"),
        metric_card("TP2", f"${tps.get('tp2', result.take_profit):,.2f}", tone="long"),
    ], columns=4)

    _render_metric_row([
        metric_card("TP3", f"${tps.get('tp3', result.take_profit):,.2f}", tone="long"),
        metric_card("TP4", f"${tps.get('tp4', result.take_profit):,.2f}", tone="long"),
        metric_card("Risk / Reward", f"{result.risk_reward:.2f}", tone="long" if result.risk_reward >= 1.5 else "wait"),
        metric_card("Legacy TP", f"${result.take_profit:,.2f}", tone="long"),
    ], columns=4)

    st.markdown("<div class='section-gap section-gap--sm'></div>", unsafe_allow_html=True)

    left, right = st.columns(2, gap="large")
    with left:
        st.markdown(
            checklist_panel(title="Reasons to enter", items=result.reasons_enter or ["Run analysis for checklist"], positive=True),
            unsafe_allow_html=True,
        )
    with right:
        st.markdown(
            checklist_panel(title="Reasons NOT to enter", items=result.reasons_avoid or ["Run analysis for warnings"], positive=False),
            unsafe_allow_html=True,
        )


def render_risk_tab(result: AnalysisResult, *, risk_settings: dict[str, float]) -> None:
    st.markdown(section_heading("Risk Overview"), unsafe_allow_html=True)
    st.markdown(risk_enhanced_panel(result.risk_profile), unsafe_allow_html=True)

    max_risk_pct = float(risk_settings.get("max_risk_pct", 1.0))
    account_size = float(risk_settings.get("account_size", 10000.0))
    risk_per_unit = abs(result.price - result.stop_loss)
    max_risk_usd = account_size * (max_risk_pct / 100)
    position_size = max_risk_usd / risk_per_unit if risk_per_unit > 0 else 0.0
    position_value = position_size * result.price
    pct = confidence_percent(result.confidence)

    st.markdown("<div class='section-gap section-gap--sm'></div>", unsafe_allow_html=True)
    _render_metric_row([
        metric_card("Sidebar Risk / Trade", f"{max_risk_pct:.2f}%"),
        metric_card("Risk Budget", f"${max_risk_usd:,.2f}"),
        metric_card("Est. Position Size", f"{position_size:.4f} BTC"),
        metric_card("Position Value", f"${position_value:,.2f}"),
    ])

    summary = signal_plain_language_summary(result.recommendation, result.confidence, result.score)
    lines = [
        f"Stop distance: ${risk_per_unit:,.2f} per BTC",
        f"Direction: {result.recommendation.upper()} (score {result.score:.0f}/100)",
        f"Signal strength: {result.confidence} ({pct}%)",
        "",
        summary[2][1],
        "",
        "Position sizing uses sidebar settings. AI engine uses 1% risk baseline for suggestions.",
    ]
    st.markdown(prose_block("\n".join(lines)), unsafe_allow_html=True)
    st.markdown(
        risk_warning_banner(result.recommendation, result.confidence, result.score),
        unsafe_allow_html=True,
    )


def render_indicators_tab(result: AnalysisResult) -> None:
    st.markdown(section_heading("Technical Indicators"), unsafe_allow_html=True)
    rows = indicator_rows(result)
    for i in range(0, len(rows), 4):
        chunk = rows[i : i + 4]
        _render_metric_row(
            [metric_card(label, value, tone=tone) for label, value, tone in chunk],
            columns=min(4, len(chunk)),
        )
        st.markdown("<div class='section-gap section-gap--sm'></div>", unsafe_allow_html=True)

    st.markdown(section_heading("Signal Components"), unsafe_allow_html=True)
    cols = st.columns(3, gap="medium")
    for idx, component in enumerate(result.components):
        with cols[idx % 3]:
            st.markdown(component_card(component.name, component.score, component.detail), unsafe_allow_html=True)


def render_dashboard(
    result: AnalysisResult,
    *,
    dark: bool,
    risk_settings: dict[str, float] | None = None,
) -> None:
    settings = risk_settings or {}
    tabs = st.tabs([
        "AI Dashboard",
        "Overview",
        "Trade Setup",
        "Risk",
        "Indicators",
    ])

    with tabs[0]:
        render_ai_dashboard_tab(result, dark=dark)
    with tabs[1]:
        render_overview_tab(result, dark=dark)
    with tabs[2]:
        render_trade_setup_tab(result)
    with tabs[3]:
        render_risk_tab(result, risk_settings=settings)
    with tabs[4]:
        render_indicators_tab(result)

    st.markdown("<div class='section-gap section-gap--sm'></div>", unsafe_allow_html=True)
    st.markdown(
        brand_footer(sources=", ".join(result.data_sources)),
        unsafe_allow_html=True,
    )
```

---

<a id="file-src-ui-components-py"></a>
## File: `src/ui/components.py`

```python
"""UI entry points — thin facade over dashboard and shared widgets."""

from __future__ import annotations

from datetime import datetime

import streamlit as st

from src.ui.dashboard import render_dashboard
from src.ui.time_utils import normalize_last_updated
from src.ui.tradingview import render_tradingview_chart
from src.ui.primitives import empty_state, error_state, premium_nav

__all__ = [
    "render_header_bar",
    "render_analyze_button",
    "render_empty_state",
    "render_error_state",
    "render_dashboard",
    "render_tradingview_chart",
]


def render_header_bar(last_updated: datetime | None = None) -> None:
    """Render the premium navigation header."""
    safe_updated = normalize_last_updated(last_updated)
    st.markdown(premium_nav(last_updated=safe_updated), unsafe_allow_html=True)


def render_analyze_button() -> bool:
    return st.button("Analyze Market", type="primary", use_container_width=True)


def render_empty_state() -> None:
    st.markdown(
        empty_state(
            title="Ready to analyze",
            description="Press Analyze Market in the sidebar to fetch live data and open the dashboard.",
        ),
        unsafe_allow_html=True,
    )


def render_error_state(message: str) -> None:
    st.markdown(error_state(message), unsafe_allow_html=True)
```

---

<a id="file-src-ui-tradingview-py"></a>
## File: `src/ui/tradingview.py`

```python
"""TradingView BTCUSDT chart embed for Streamlit."""

from __future__ import annotations

import html
import time

import streamlit as st
import streamlit.components.v1 as components

from src.ui.sidebar import AUTO_REFRESH_SECONDS

INTERVAL_MAP = {
    "1m": "1",
    "15m": "15",
    "1h": "60",
    "4h": "240",
    "1d": "D",
}

CHART_REFRESH_SECONDS = AUTO_REFRESH_SECONDS


def render_tradingview_chart(
    *,
    symbol: str = "BINANCE:BTCUSDT",
    interval: str = "1m",
    height: int = 520,
    dark: bool = True,
    refresh_seconds: int = CHART_REFRESH_SECONDS,
) -> None:
    """Embed a live TradingView chart that reloads on a fixed interval."""
    tv_interval = INTERVAL_MAP.get(interval, "60")
    theme = "dark" if dark else "light"

    iframe_src = (
        "https://s.tradingview.com/widgetembed/?"
        f"symbol={symbol}&interval={tv_interval}&hidesidetoolbar=0&"
        f"symboledit=0&saveimage=0&toolbarbg=f1f3f6&studies=[]&"
        f"theme={theme}&style=1&timezone=Etc%2FUTC&withdateranges=1&"
        "hidelegend=0&hidevolume=0&allow_symbol_change=0"
    )
    cache_bust = int(time.time() // max(refresh_seconds, 1))
    initial_src = f"{iframe_src}&_={cache_bust}"
    safe_src = html.escape(initial_src, quote=True)
    safe_base = html.escape(iframe_src, quote=True)

    components.html(
        f"""
        <div style="width:100%;height:{height}px;overflow:hidden;border-radius:10px;">
            <iframe
                id="btc-live-chart"
                src="{safe_src}"
                style="width:100%;height:100%;border:0;"
                allow="fullscreen"
                loading="lazy"
            ></iframe>
        </div>
        <script>
            (function () {{
                var refreshMs = {int(refresh_seconds) * 1000};
                var baseSrc = "{safe_base}";
                setInterval(function () {{
                    var frame = document.getElementById("btc-live-chart");
                    if (!frame) return;
                    frame.src = baseSrc + "&_=" + Date.now();
                }}, refreshMs);
            }})();
        </script>
        """,
        height=height + 8,
        scrolling=False,
    )

    st.caption(
        f"Live chart powered by TradingView · BINANCE:BTCUSDT · refreshes every {refresh_seconds}s"
    )
```

---
