"""HTML primitives for the dashboard UI."""

from __future__ import annotations

import html
from datetime import datetime

from src.ui.time_utils import format_last_updated, normalize_last_updated
from src.ui.theme import APP_VERSION, BRAND, RECOMMENDATION_STYLE, brand_caption, confidence_percent, score_tone


def premium_nav(*, last_updated: datetime | None = None) -> str:
    """Sticky premium SaaS navigation header."""
    title = html.escape(BRAND["product"])
    tagline = html.escape(brand_caption())

    dt = normalize_last_updated(last_updated)
    updated_text = html.escape(format_last_updated(dt))
    if dt is not None:
        status_label = "Live"
        status_class = "status-dot--live"
    else:
        status_label = "Ready"
        status_class = "status-dot--idle"

    return f"""
    <header class="premium-nav-outer">
        <div class="premium-nav">
            <div class="premium-nav__inner">
                <div class="premium-nav__left">
                    <div class="premium-nav__logo" aria-label="Bitcoin">
                        <span class="premium-nav__logo-symbol">₿</span>
                        <span class="premium-nav__logo-text">Bitcoin</span>
                    </div>
                    <div class="premium-nav__brand">
                        <h1 class="premium-nav__title">{title}</h1>
                        <p class="premium-nav__tagline">{tagline}</p>
                    </div>
                </div>
                <div class="premium-nav__right">
                    <div class="premium-nav__status">
                        <span class="status-dot {status_class}" aria-hidden="true"></span>
                        <span>{status_label}</span>
                    </div>
                    <div class="premium-nav__updated">
                        <span class="premium-nav__updated-label">Updated</span>
                        {updated_text}
                    </div>
                </div>
            </div>
            <div class="premium-nav__divider" aria-hidden="true"></div>
        </div>
    </header>
    """


def section_heading(text: str) -> str:
    return f'<h3 class="section-heading">{html.escape(text)}</h3>'


def metric_card(label: str, value: str, *, tone: str | None = None) -> str:
    tone_cls = f" card--tone-{tone}" if tone else ""
    return f"""
    <div class="card card--metric card--elevated{tone_cls}">
        <div class="card__label">{html.escape(label)}</div>
        <div class="card__value">{html.escape(value)}</div>
    </div>
    """


def metric_card_wrap(inner: str) -> str:
    return f'<div class="card-wrap">{inner}</div>'


def component_card(name: str, score: float, detail: str) -> str:
    tone = score_tone(score)
    return f"""
    <div class="card card--component card--elevated card--tone-{tone}">
        <div class="card__label">{html.escape(name)}</div>
        <div class="card__value">{score:.0f}<span class="card__suffix">/100</span></div>
        <div class="progress-track">
            <div class="progress-fill progress-fill--{tone}" style="width:{score:.0f}%;"></div>
        </div>
        <p class="card__detail">{html.escape(detail)}</p>
    </div>
    """


def recommendation_panel(
    recommendation: str,
    insight: str,
    confidence: str,
    score: float,
    *,
    summary_rows: list[tuple[str, str]] | None = None,
    show_meaning: bool = True,
    show_insight: bool = True,
) -> str:
    style = RECOMMENDATION_STYLE[recommendation]
    pct = confidence_percent(confidence)

    meaning_html = ""
    if show_meaning:
        if summary_rows is None:
            from src.ui.helpers import signal_plain_language_summary

            summary_rows = signal_plain_language_summary(recommendation, confidence, score)

        summary_html = "".join(
            f"""
            <div class="signal-summary__row">
                <div class="signal-summary__label">{html.escape(label)}</div>
                <p class="signal-summary__text">{html.escape(text)}</p>
            </div>
            """
            for label, text in summary_rows
        )
        meaning_html = f"""
        <div class="signal-summary">
            <div class="signal-summary__heading">What this means</div>
            {summary_html}
        </div>
        """

    insight_html = ""
    if show_insight:
        insight_html = f'<p class="rec-panel__insight">{html.escape(insight)}</p>'

    return f"""
    <div class="rec-panel card--elevated rec-panel--{style['tone']}">
        <div class="signal-badge signal-badge--{style['tone']}">{style['label']}</div>
        {insight_html}
        {meaning_html}
        <div class="rec-panel__confidence">
            <div class="rec-panel__conf-row">
                <span class="card__label">Signal strength</span>
                <span class="rec-panel__conf-value">{html.escape(confidence)} · {pct}%</span>
            </div>
            <div class="progress-track progress-track--lg">
                <div class="progress-fill progress-fill--{style['tone']}" style="width:{pct}%;"></div>
            </div>
        </div>
    </div>
    """


def risk_warning_banner(
    recommendation: str,
    confidence: str,
    score: float,
) -> str:
    pct = confidence_percent(confidence)
    if pct >= 70 or recommendation == "wait":
        return ""

    direction = recommendation.upper()
    return f"""
    <div class="risk-alert risk-alert--banner" role="alert">
        <strong>Heads up</strong>
        <span>
            Direction is {direction} (score {score:.0f}/100), but signal strength is only {pct}%.
            Read the summary below before entering — waiting is often the safer choice.
        </span>
    </div>
    """


def empty_state(*, title: str, description: str, compact: bool = False) -> str:
    cls = "state-panel state-panel--empty"
    if compact:
        cls += " state-panel--compact"
    return f"""
    <div class="{cls}">
        <div class="state-panel__icon">📊</div>
        <div class="state-panel__title">{html.escape(title)}</div>
        <p class="state-panel__desc">{html.escape(description)}</p>
    </div>
    """


def error_state(message: str) -> str:
    return f"""
    <div class="state-panel state-panel--error" role="alert">
        <div class="state-panel__title">Analysis failed</div>
        <p class="state-panel__desc">{html.escape(message)}</p>
    </div>
    """


def prose_block(text: str) -> str:
    return f'<div class="card card--prose card--elevated">{html.escape(text)}</div>'


def brand_footer(*, sources: str) -> str:
    return f"""
    <footer class="brand-footer">
        <p class="brand-footer__disclaimer">Educational tool only. Not financial advice.</p>
        <p class="brand-footer__meta">
            Built by {html.escape(BRAND['author_en'])} · {html.escape(BRAND['website_label'])} · v{html.escape(APP_VERSION)}
        </p>
        <p class="brand-footer__meta brand-footer__meta--muted">
            {html.escape(BRAND['product'])} · Data: {html.escape(sources)}
        </p>
    </footer>
    """


def data_hub_panel(hub: dict) -> str:
    if not hub:
        return empty_state(
            title="Data Hub unavailable",
            description="Run analysis to populate the unified data layer.",
            compact=True,
        )

    source_rows = []
    for name, info in (hub.get("source_status") or {}).items():
        status = html.escape(str(info.get("status", "offline")))
        updated = info.get("last_updated") or "—"
        error = info.get("error")
        status_cls = f"hub-status hub-status--{status}"
        error_html = f'<div class="hub-source__error">{html.escape(error)}</div>' if error else ""
        source_rows.append(
            f"""
            <div class="hub-source card card--elevated">
                <div class="hub-source__head">
                    <span class="hub-source__name">{html.escape(name)}</span>
                    <span class="{status_cls}">{status.upper()}</span>
                </div>
                <div class="hub-source__meta">Last updated: {html.escape(str(updated))}</div>
                {error_html}
            </div>
            """
        )

    available = ", ".join(hub.get("available_fields") or []) or "None"
    missing = ", ".join(hub.get("missing_fields") or []) or "None"
    quality = html.escape(str(hub.get("data_quality", "unknown")))
    impact = html.escape(str(hub.get("confidence_impact", "none")))
    last_updated = html.escape(str(hub.get("last_updated") or "—"))

    return f"""
    <div class="hub-panel">
        <div class="hub-summary card card--elevated">
            <div class="hub-summary__grid">
                <div><span class="card__label">Data quality</span><div class="hub-summary__value">{quality}</div></div>
                <div><span class="card__label">Last updated</span><div class="hub-summary__value">{last_updated}</div></div>
                <div><span class="card__label">Confidence impact</span><div class="hub-summary__value">{impact}</div></div>
                <div><span class="card__label">Active sources</span><div class="hub-summary__value">{len(hub.get("sources") or [])}</div></div>
            </div>
        </div>
        <div class="section-gap section-gap--sm"></div>
        <h4 class="section-heading">Connected Sources</h4>
        <div class="hub-source-grid">{''.join(source_rows)}</div>
        <div class="section-gap section-gap--sm"></div>
        <div class="hub-fields card card--prose card--elevated">
            <strong>Available data:</strong> {html.escape(available)}
            <br><br>
            <strong>Missing data:</strong> {html.escape(missing)}
        </div>
    </div>
    """


def stars_display(count: int, max_stars: int = 5) -> str:
    filled = max(0, min(max_stars, count))
    return "★" * filled + "☆" * (max_stars - filled)


def market_status_panel(*, trend: str, volatility: str, liquidity: str) -> str:
    items = [
        ("Market trend", trend, _status_tone(trend)),
        ("Volatility", volatility, _status_tone(volatility)),
        ("Liquidity", liquidity, _status_tone(liquidity)),
    ]
    cards = "".join(
        f"""
        <div class="card card--metric card--elevated card--tone-{tone}">
            <div class="card__label">{html.escape(label)}</div>
            <div class="card__value card__value--sm">{html.escape(value)}</div>
        </div>
        """
        for label, value, tone in items
    )
    return f'<div class="status-grid">{cards}</div>'


def _status_tone(value: str) -> str:
    lower = value.lower()
    if "bull" in lower:
        return "long"
    if "bear" in lower:
        return "short"
    if "high" in lower or "low" in lower:
        return "wait"
    return "wait"


def trade_quality_panel(*, grade: str, score: int, stars: int) -> str:
    tone = "long" if grade in {"A+", "A"} else "wait" if grade == "B" else "short" if grade == "C" else "wait"
    if grade == "No Trade":
        tone = "short"
    return f"""
    <div class="card card--elevated trade-quality card--tone-{tone}">
        <div class="card__label">Trade Quality</div>
        <div class="trade-quality__grade">{html.escape(grade)}</div>
        <div class="trade-quality__score">{score}/100</div>
        <div class="trade-quality__stars" aria-label="{stars} of 5 stars">{stars_display(stars)}</div>
    </div>
    """


def checklist_panel(*, title: str, items: list[str], positive: bool = True) -> str:
    cls = "checklist checklist--positive" if positive else "checklist checklist--negative"
    icon = "✓" if positive else "!"
    rows = "".join(
        f'<li class="checklist__item"><span class="checklist__icon">{icon}</span>{html.escape(item)}</li>'
        for item in items
    )
    return f"""
    <div class="card card--elevated {cls}">
        <div class="card__label">{html.escape(title)}</div>
        <ul class="checklist__list">{rows}</ul>
    </div>
    """


def source_status_panel(source_status: dict) -> str:
    if not source_status:
        return empty_state(title="No source status", description="Run analysis first.", compact=True)

    rows = []
    for name, status in source_status.items():
        status_str = html.escape(str(status))
        cls = f"hub-status hub-status--{status_str}"
        rows.append(
            f"""
            <div class="source-pill card card--elevated">
                <span class="source-pill__name">{html.escape(name)}</span>
                <span class="{cls}">{status_str.upper()}</span>
            </div>
            """
        )
    return f'<div class="source-status-grid">{"".join(rows)}</div>'


def fear_greed_panel(data: dict) -> str:
    if not data or data.get("value") is None:
        msg = html.escape(str(data.get("error") or "Fear & Greed data unavailable"))
        return f'<div class="card card--elevated card--prose">{msg}</div>'

    value = int(data["value"])
    tone = "long" if value >= 55 else "short" if value <= 45 else "wait"
    return f"""
    <div class="card card--elevated card--tone-{tone}">
        <div class="card__label">Fear &amp; Greed Index</div>
        <div class="card__value">{value}</div>
        <div class="card__detail">{html.escape(str(data.get("classification", "")))}</div>
        <div class="card__detail">Provider: {html.escape(str(data.get("provider", "Alternative.me")))}</div>
    </div>
    """


def news_sentiment_panel(data: dict) -> str:
    summary = data.get("summary") or {}
    headlines = data.get("headlines") or []
    headline_rows = "".join(
        f"""
        <li class="news-item news-item--{html.escape(str(item.get('sentiment', 'neutral')))}">
            <span class="news-item__source">{html.escape(str(item.get('source', '')))}</span>
            {html.escape(str(item.get('title', '')))}
        </li>
        """
        for item in headlines[:8]
    )
    if not headline_rows:
        headline_rows = "<li class='news-item'>No headlines fetched.</li>"

    return f"""
    <div class="card card--elevated news-panel">
        <div class="card__label">News Sentiment</div>
        <div class="news-panel__summary">
            {html.escape(str(summary.get('label', 'neutral')).title())}
            · score {summary.get('score', 50)}/100
            · +{summary.get('positive', 0)} / −{summary.get('negative', 0)} headlines
        </div>
        <ul class="news-panel__list">{headline_rows}</ul>
    </div>
    """


def risk_enhanced_panel(risk_profile: dict) -> str:
    if not risk_profile:
        return empty_state(title="Risk data unavailable", description="Run analysis first.", compact=True)

    return f"""
    <div class="card card--elevated risk-panel">
        <div class="risk-panel__grid">
            <div><span class="card__label">Risk Level</span><div class="card__value card__value--sm">{html.escape(str(risk_profile.get('level', 'N/A')))}</div></div>
            <div><span class="card__label">Probability</span><div class="card__value card__value--sm">{float(risk_profile.get('probability', 0)):.0%}</div></div>
            <div><span class="card__label">Invalidation</span><div class="card__value card__value--sm">${float(risk_profile.get('invalidation', 0)):,.2f}</div></div>
            <div><span class="card__label">Position (1% risk)</span><div class="card__value card__value--sm">{float(risk_profile.get('position_size_btc', 0)):.6f} BTC</div></div>
        </div>
        <p class="card__detail">Risk budget: ${float(risk_profile.get('risk_per_trade_usd', 0)):,.2f} · Notional: ${float(risk_profile.get('position_size_usd', 0)):,.2f}</p>
    </div>
    """


def placeholder_data_panel(title: str, payload: dict) -> str:
    rows = []
    for key, info in (payload or {}).items():
        if not isinstance(info, dict):
            continue
        status = html.escape(str(info.get("status", "unavailable")))
        message = html.escape(str(info.get("message") or info.get("provider") or ""))
        rows.append(
            f"""
            <div class="placeholder-row">
                <strong>{html.escape(key.replace('_', ' ').title())}</strong>
                <span class="hub-status hub-status--{status}">{status.upper()}</span>
                <div class="card__detail">{message}</div>
            </div>
            """
        )
    body = "".join(rows) or "<p class='card__detail'>No data available.</p>"
    return f"""
    <div class="card card--elevated card--prose">
        <div class="card__label">{html.escape(title)}</div>
        {body}
    </div>
    """

