"""Coinbase connector placeholder — future multi-exchange support."""

from __future__ import annotations

from src.data.connectors.base import BaseConnector
from src.data.hub_models import SourceInfo


class CoinbaseConnector(BaseConnector):
    name = "Coinbase"
    enabled = False

    def probe(self) -> SourceInfo:
        return self._info(
            status="placeholder",
            fields=["price", "candles", "volume"],
            error="Connector placeholder — API integration pending",
        )

    def fetch_snapshot(self) -> dict:
        return {
            "status": "placeholder",
            "message": "Coinbase connector not yet connected",
            "fields": ["price", "candles", "volume"],
        }
