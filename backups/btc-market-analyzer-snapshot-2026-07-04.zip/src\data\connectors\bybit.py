"""Bybit connector placeholder — future multi-exchange support."""

from __future__ import annotations

from src.data.connectors.base import BaseConnector
from src.data.hub_models import SourceInfo


class BybitConnector(BaseConnector):
    name = "Bybit"
    enabled = False

    def probe(self) -> SourceInfo:
        return self._info(
            status="placeholder",
            fields=["price", "candles", "funding_rate", "open_interest"],
            error="Connector placeholder — API integration pending",
        )

    def fetch_snapshot(self) -> dict:
        return {
            "status": "placeholder",
            "message": "Bybit connector not yet connected",
            "fields": ["price", "candles", "funding_rate", "open_interest"],
        }
