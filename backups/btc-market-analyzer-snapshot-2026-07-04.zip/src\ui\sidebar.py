"""Sidebar settings and controls."""

from __future__ import annotations

import os
from dataclasses import dataclass

import streamlit as st

__all__ = ["SidebarSettings", "render_sidebar"]

AUTO_REFRESH_SECONDS = 60
AUTO_TIMEFRAME = "1m"
DEFAULT_ACCOUNT_SIZE = 10_000.0


@dataclass
class SidebarSettings:
    symbol: str
    interval: str
    api_key: str
    dark_mode: bool
    analyze_clicked: bool
    auto_refresh: bool
    refresh_seconds: int
    risk_settings: dict[str, float]


def render_sidebar() -> SidebarSettings:
    """Return sidebar configuration and whether Analyze was clicked."""
    if "max_risk_pct" not in st.session_state:
        st.session_state.max_risk_pct = 1.0

    with st.sidebar:
        st.markdown('<p class="sidebar-label">Market</p>', unsafe_allow_html=True)
        symbol = st.selectbox("Symbol", ["BTCUSDT"], index=0)
        st.caption(f"Timeframe: {AUTO_TIMEFRAME} (fixed)")

        st.markdown("---")
        analyze_clicked = st.button("Analyze Market", type="primary", use_container_width=True)
        st.caption(f"Auto refresh: every {AUTO_REFRESH_SECONDS} seconds")

        st.markdown("---")
        st.markdown('<p class="sidebar-label">Risk Settings</p>', unsafe_allow_html=True)
        max_risk_pct = st.slider(
            "Max risk per trade (%)",
            min_value=0.25,
            max_value=5.0,
            value=float(st.session_state.max_risk_pct),
            step=0.25,
            help="Used for position sizing estimates in the Risk tab.",
        )
        st.session_state.max_risk_pct = max_risk_pct

        st.markdown("---")
        st.markdown('<p class="sidebar-label">Data</p>', unsafe_allow_html=True)
        api_key = st.text_input(
            "Coinglass API Key (optional)",
            value=os.getenv("COINGLASS_API_KEY", ""),
            type="password",
            help="Enables liquidation heatmap and enriched derivatives data.",
        )

    return SidebarSettings(
        symbol=symbol,
        interval=AUTO_TIMEFRAME,
        api_key=api_key,
        dark_mode=True,
        analyze_clicked=analyze_clicked,
        auto_refresh=True,
        refresh_seconds=AUTO_REFRESH_SECONDS,
        risk_settings={
            "max_risk_pct": max_risk_pct,
            "account_size": DEFAULT_ACCOUNT_SIZE,
        },
    )
