"""Regenerate PROJECT_EXPORT.md from all project source files."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "PROJECT_EXPORT.md"

FILES = [
    "requirements.txt",
    ".env.example",
    ".gitignore",
    "README.md",
    "app.py",
    "generate_export.py",
    "assets/README.txt",
    "src/data/__init__.py",
    "src/data/binance_client.py",
    "src/data/cache.py",
    "src/data/coinglass_client.py",
    "src/data/data_hub.py",
    "src/data/fear_greed.py",
    "src/data/hub_models.py",
    "src/data/news_client.py",
    "src/data/news_sentiment.py",
    "src/data/onchain.py",
    "src/data/onchain_client.py",
    "src/data/whale_client.py",
    "src/data/connectors/__init__.py",
    "src/data/connectors/base.py",
    "src/data/connectors/binance_connector.py",
    "src/data/connectors/bybit.py",
    "src/data/connectors/coinbase.py",
    "src/data/connectors/kraken.py",
    "src/data/connectors/okx.py",
    "src/indicators/technical.py",
    "src/analysis/models.py",
    "src/analysis/scorer.py",
    "src/analysis/sentiment.py",
    "src/analysis/risk_manager.py",
    "src/analysis/ai_decision_engine.py",
    "src/ui/__init__.py",
    "src/ui/theme.py",
    "src/ui/time_utils.py",
    "src/ui/helpers.py",
    "src/ui/primitives.py",
    "src/ui/styles.py",
    "src/ui/background.py",
    "src/ui/charts.py",
    "src/ui/sidebar.py",
    "src/ui/dashboard.py",
    "src/ui/components.py",
    "src/ui/tradingview.py",
]

LANG = {
    ".py": "python",
    ".md": "markdown",
    ".txt": "text",
    ".example": "text",
    "": "text",
}


def main() -> None:
    lines: list[str] = [
        "# Ofir Kadosh Bitcoin AI Dashboard — Full Project Export",
        "",
        f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}",
        f"Location: `{ROOT}`",
        "",
        "## Table of Contents",
        "",
    ]

    for rel in FILES:
        anchor = rel.replace("/", "-").replace(".", "-").replace("\\", "-")
        lines.append(f"- [{rel}](#file-{anchor})")

    lines.extend(["", "---", ""])

    for rel in FILES:
        path = ROOT / rel
        if not path.is_file():
            continue
        suffix = path.suffix
        lang = LANG.get(suffix, "text")
        anchor = rel.replace("/", "-").replace(".", "-").replace("\\", "-")
        content = path.read_text(encoding="utf-8").rstrip()

        lines.extend([
            f"<a id=\"file-{anchor}\"></a>",
            f"## File: `{rel}`",
            "",
            f"```{lang}",
            content,
            "```",
            "",
            "---",
            "",
        ])

    OUTPUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {OUTPUT} ({OUTPUT.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
