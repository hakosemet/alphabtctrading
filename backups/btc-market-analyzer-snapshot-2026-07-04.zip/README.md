# Bitcoin Market Analyzer

Python app that analyzes the Bitcoin market using Binance spot/futures data and optional Coinglass derivatives data. Computes EMA, MACD, RSI, volume, and a price heatmap, then outputs a 0–100 score with a **long**, **short**, or **wait** recommendation.

## Features

- Live OHLCV from Binance
- Technical indicators: EMA (9/21/50/200), MACD, RSI, volume analysis
- Heatmap: Coinglass liquidation heatmap (with API key) or Binance volume profile fallback
- Derivatives context: funding rate, long/short ratio, open interest change
- Composite score (0–100), confidence, stop loss, take profit, and written explanation
- Simple Streamlit UI with an **Analyze** button

## Quick start

```bash
cd btc-market-analyzer
python -m venv .venv
.venv\Scripts\activate        # Windows
pip install -r requirements.txt
copy .env.example .env          # optional: add COINGLASS_API_KEY
streamlit run app.py
```

Open the URL shown in the terminal (usually http://localhost:8501).

## Coinglass API (optional)

Coinglass requires a paid API key for programmatic access. Without it, the app still works using Binance data and a volume-profile heatmap.

1. Get an API key from [Coinglass](https://www.coinglass.com/pricing)
2. Add it to `.env`:

```
COINGLASS_API_KEY=your_key_here
```

Or paste it in the sidebar when running the app.

## Scoring logic

| Component | Weight | Bullish when… |
|-----------|--------|---------------|
| EMA Trend | 25% | Price above EMAs, golden cross structure |
| MACD | 20% | MACD above signal, rising histogram |
| RSI | 15% | Oversold bounce or bullish zone (not overbought) |
| Volume | 15% | Above-average volume with taker buy dominance |
| Heatmap | 10% | More liquidation/support intensity below price |
| Derivatives | 15% | Neutral/negative funding, balanced positioning |

- **Score ≥ 62** → Long  
- **Score ≤ 38** → Short  
- **Otherwise** → Wait  

Stop loss and take profit use ATR-based levels adjusted by heatmap support/resistance zones.

## Disclaimer

This tool is for educational and research purposes only. It is not financial advice. Cryptocurrency trading involves substantial risk.
